package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PharmacyRepository
import com.example.data.models.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    CATALOG_FILTER,
    COMPARE,
    BLOG_VIDEO,
    SUPPORT_TICKETS,
    PROFILE_ORDERS,
    ADMIN
}

enum class SortOption(val titleFa: String) {
    POPULAR("محبوب‌ترین و پرفروش"),
    RATING("بالاترین امتیاز رضایت"),
    PRICE_LOW_TO_HIGH("ارزان‌ترین"),
    PRICE_HIGH_TO_LOW("گران‌ترین"),
    DISCOUNT("بیشترین تخفیف")
}

class PharmacyViewModel(
    val repository: PharmacyRepository = PharmacyRepository()
) : ViewModel() {

    // Current Screen
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Search and Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(ProductCategory.ALL)
    val selectedCategory: StateFlow<ProductCategory> = _selectedCategory.asStateFlow()

    private val _filterInStockOnly = MutableStateFlow(false)
    val filterInStockOnly: StateFlow<Boolean> = _filterInStockOnly.asStateFlow()

    private val _filterDiscountOnly = MutableStateFlow(false)
    val filterDiscountOnly: StateFlow<Boolean> = _filterDiscountOnly.asStateFlow()

    private val _filterInstallmentOnly = MutableStateFlow(false)
    val filterInstallmentOnly: StateFlow<Boolean> = _filterInstallmentOnly.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.POPULAR)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    // Selected product for detail view
    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    // Sayad Calculator Modal State
    private val _showSayadCalculator = MutableStateFlow(false)
    val showSayadCalculator: StateFlow<Boolean> = _showSayadCalculator.asStateFlow()

    private val _calcSelectedMonths = MutableStateFlow(6)
    val calcSelectedMonths: StateFlow<Int> = _calcSelectedMonths.asStateFlow()

    private val _calcDownPaymentPercent = MutableStateFlow(25)
    val calcDownPaymentPercent: StateFlow<Int> = _calcDownPaymentPercent.asStateFlow()

    private val _calcBaseAmount = MutableStateFlow(4850000L)
    val calcBaseAmount: StateFlow<Long> = _calcBaseAmount.asStateFlow()

    // Checkout & Online Payment
    private val _showCheckoutSheet = MutableStateFlow(false)
    val showCheckoutSheet: StateFlow<Boolean> = _showCheckoutSheet.asStateFlow()

    private val _selectedGateway = MutableStateFlow("بانک سامان (شاپرک)")
    val selectedGateway: StateFlow<String> = _selectedGateway.asStateFlow()

    private val _isInstallmentCheckout = MutableStateFlow(false)
    val isInstallmentCheckout: StateFlow<Boolean> = _isInstallmentCheckout.asStateFlow()

    private val _paymentSuccessOrder = MutableStateFlow<Order?>(null)
    val paymentSuccessOrder: StateFlow<Order?> = _paymentSuccessOrder.asStateFlow()

    // AI Consultant Sheet
    private val _showAiConsultant = MutableStateFlow(false)
    val showAiConsultant: StateFlow<Boolean> = _showAiConsultant.asStateFlow()

    // Tracking Order Modal
    private val _trackedOrder = MutableStateFlow<Order?>(null)
    val trackedOrder: StateFlow<Order?> = _trackedOrder.asStateFlow()

    data class FilterState(
        val query: String,
        val category: ProductCategory,
        val inStockOnly: Boolean,
        val discountOnly: Boolean,
        val installmentOnly: Boolean,
        val sort: SortOption
    )

    private val filterState = combine(
        combine(_searchQuery, _selectedCategory, _filterInStockOnly) { q, c, s -> Triple(q, c, s) },
        combine(_filterDiscountOnly, _filterInstallmentOnly, _sortOption) { d, i, so -> Triple(d, i, so) }
    ) { (q, c, s), (d, i, so) ->
        FilterState(q, c, s, d, i, so)
    }

    // Filtered Products
    val filteredProducts: StateFlow<List<Product>> = combine(
        repository.products,
        filterState
    ) { products, state ->
        var list = products

        if (state.category != ProductCategory.ALL) {
            list = list.filter { it.category == state.category }
        }

        if (state.query.isNotBlank()) {
            val q = state.query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.genericName.lowercase().contains(q) ||
                it.brand.lowercase().contains(q) ||
                it.activeIngredients.lowercase().contains(q) ||
                it.description.lowercase().contains(q)
            }
        }

        if (state.inStockOnly) {
            list = list.filter { it.inStock }
        }

        if (state.discountOnly) {
            list = list.filter { it.discountPercent > 0 }
        }

        if (state.installmentOnly) {
            list = list.filter { it.isInstallmentEligible }
        }

        when (state.sort) {
            SortOption.POPULAR -> list.sortedByDescending { it.reviewCount }
            SortOption.RATING -> list.sortedByDescending { it.rating }
            SortOption.PRICE_LOW_TO_HIGH -> list.sortedBy { it.price }
            SortOption.PRICE_HIGH_TO_LOW -> list.sortedByDescending { it.price }
            SortOption.DISCOUNT -> list.sortedByDescending { it.discountPercent }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.products.value)

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun selectCategory(category: ProductCategory) {
        _selectedCategory.value = category
    }

    fun setFilterInStockOnly(value: Boolean) {
        _filterInStockOnly.value = value
    }

    fun setFilterDiscountOnly(value: Boolean) {
        _filterDiscountOnly.value = value
    }

    fun setFilterInstallmentOnly(value: Boolean) {
        _filterInstallmentOnly.value = value
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    fun selectProduct(product: Product?) {
        _selectedProduct.value = product
    }

    // Sayad Calculator
    fun openSayadCalculator(baseAmount: Long? = null) {
        if (baseAmount != null && baseAmount > 0) {
            _calcBaseAmount.value = baseAmount
        }
        _showSayadCalculator.value = true
    }

    fun closeSayadCalculator() {
        _showSayadCalculator.value = false
    }

    fun setCalcMonths(months: Int) {
        _calcSelectedMonths.value = months
    }

    fun setCalcDownPaymentPercent(percent: Int) {
        _calcDownPaymentPercent.value = percent
    }

    fun setCalcBaseAmount(amount: Long) {
        _calcBaseAmount.value = amount
    }

    fun getSayadCalculation(): SayadCalculationResult {
        return repository.calculateSayadInstallments(
            totalAmount = _calcBaseAmount.value,
            downPaymentPercent = _calcDownPaymentPercent.value,
            months = _calcSelectedMonths.value
        )
    }

    // Checkout
    fun openCheckout(isInstallment: Boolean = false) {
        _isInstallmentCheckout.value = isInstallment
        _showCheckoutSheet.value = true
    }

    fun closeCheckout() {
        _showCheckoutSheet.value = false
    }

    fun selectGateway(gateway: String) {
        _selectedGateway.value = gateway
    }

    fun processPayment(
        address: String,
        name: String,
        phone: String
    ) {
        val sayadCheques = if (_isInstallmentCheckout.value) _calcSelectedMonths.value else 0
        val newOrder = repository.placeOrder(
            gateway = _selectedGateway.value,
            isInstallment = _isInstallmentCheckout.value,
            sayadCheques = sayadCheques,
            address = address,
            name = name,
            phone = phone
        )
        _paymentSuccessOrder.value = newOrder
        _showCheckoutSheet.value = false
        _trackedOrder.value = newOrder
    }

    fun clearPaymentSuccessOrder() {
        _paymentSuccessOrder.value = null
    }

    fun trackOrder(order: Order?) {
        _trackedOrder.value = order
    }

    fun openAiConsultant() {
        _showAiConsultant.value = true
    }

    fun closeAiConsultant() {
        _showAiConsultant.value = false
    }

    fun triggerExitPopup() {
        repository.triggerExitDiscountPopup()
    }
}
