package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen
import com.example.viewmodel.PharmacyViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PharmacyAppRoot()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyAppRoot(
    viewModel: PharmacyViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val allProducts by viewModel.repository.products.collectAsStateWithLifecycle()
    val cartItems by viewModel.repository.cartItems.collectAsStateWithLifecycle()
    val comparisonList by viewModel.repository.comparisonList.collectAsStateWithLifecycle()
    val orders by viewModel.repository.orders.collectAsStateWithLifecycle()
    val tickets by viewModel.repository.tickets.collectAsStateWithLifecycle()
    val articles by viewModel.repository.articles.collectAsStateWithLifecycle()
    val notifications by viewModel.repository.notifications.collectAsStateWithLifecycle()
    val chatMessages by viewModel.repository.liveChatMessages.collectAsStateWithLifecycle()
    val appliedCoupon by viewModel.repository.appliedCouponCode.collectAsStateWithLifecycle()
    val discountPercent by viewModel.repository.appliedDiscountPercent.collectAsStateWithLifecycle()
    val showExitPopup by viewModel.repository.showExitDiscountPopup.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val inStockOnly by viewModel.filterInStockOnly.collectAsStateWithLifecycle()
    val discountOnly by viewModel.filterDiscountOnly.collectAsStateWithLifecycle()
    val installmentOnly by viewModel.filterInstallmentOnly.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()

    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val showSayadCalc by viewModel.showSayadCalculator.collectAsStateWithLifecycle()
    val calcMonths by viewModel.calcSelectedMonths.collectAsStateWithLifecycle()
    val calcDownPayment by viewModel.calcDownPaymentPercent.collectAsStateWithLifecycle()
    val calcBaseAmount by viewModel.calcBaseAmount.collectAsStateWithLifecycle()

    val showCheckout by viewModel.showCheckoutSheet.collectAsStateWithLifecycle()
    val selectedGateway by viewModel.selectedGateway.collectAsStateWithLifecycle()
    val isInstallmentCheckout by viewModel.isInstallmentCheckout.collectAsStateWithLifecycle()
    val paymentSuccessOrder by viewModel.paymentSuccessOrder.collectAsStateWithLifecycle()

    val showAiConsultant by viewModel.showAiConsultant.collectAsStateWithLifecycle()
    val trackedOrder by viewModel.trackedOrder.collectAsStateWithLifecycle()

    var showCartSheet by remember { mutableStateOf(false) }
    var showComparisonDialog by remember { mutableStateOf(false) }

    // Intercept back button to show exit-intent discount popup if cart has items and popup not shown yet
    BackHandler(enabled = cartItems.isNotEmpty() && appliedCoupon == null && !showExitPopup) {
        viewModel.triggerExitPopup()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            PharmacyTopBar(
                cartItems = cartItems,
                unreadNotificationCount = notifications.count { !it.isRead },
                currentScreen = currentScreen,
                onNavigate = { viewModel.navigateTo(it) },
                onOpenCart = { showCartSheet = true },
                onOpenAiConsultant = { viewModel.openAiConsultant() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.HOME,
                    onClick = { viewModel.navigateTo(AppScreen.HOME) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "خانه"
                        )
                    },
                    label = { Text("خانه", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MedicalGreenPrimary,
                        selectedTextColor = MedicalGreenPrimary,
                        indicatorColor = MedicalGreenContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.CATALOG_FILTER,
                    onClick = { viewModel.navigateTo(AppScreen.CATALOG_FILTER) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.CATALOG_FILTER) Icons.Filled.Medication else Icons.Outlined.Medication,
                            contentDescription = "محصولات"
                        )
                    },
                    label = { Text("داروها و فیلتر", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MedicalGreenPrimary,
                        selectedTextColor = MedicalGreenPrimary,
                        indicatorColor = MedicalGreenContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.BLOG_VIDEO,
                    onClick = { viewModel.navigateTo(AppScreen.BLOG_VIDEO) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.BLOG_VIDEO) Icons.Filled.PlayCircle else Icons.Outlined.PlayCircle,
                            contentDescription = "آموزش و ویدیو"
                        )
                    },
                    label = { Text("آموزش و ویدیو", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MedicalGreenPrimary,
                        selectedTextColor = MedicalGreenPrimary,
                        indicatorColor = MedicalGreenContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.SUPPORT_TICKETS,
                    onClick = { viewModel.navigateTo(AppScreen.SUPPORT_TICKETS) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.SUPPORT_TICKETS) Icons.Filled.SupportAgent else Icons.Outlined.SupportAgent,
                            contentDescription = "پشتیبانی"
                        )
                    },
                    label = { Text("پشتیبانی و تیکت", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MedicalGreenPrimary,
                        selectedTextColor = MedicalGreenPrimary,
                        indicatorColor = MedicalGreenContainer
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.PROFILE_ORDERS,
                    onClick = { viewModel.navigateTo(AppScreen.PROFILE_ORDERS) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.PROFILE_ORDERS) Icons.Filled.Person else Icons.Outlined.Person,
                            contentDescription = "پروفایل"
                        )
                    },
                    label = { Text("پروفایل و پیگیری", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MedicalGreenPrimary,
                        selectedTextColor = MedicalGreenPrimary,
                        indicatorColor = MedicalGreenContainer
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreen(
                        products = products,
                        articles = articles,
                        comparisonIds = comparisonList.map { it.id },
                        onSelectProduct = { viewModel.selectProduct(it) },
                        onAddToCart = { viewModel.repository.addToCart(it) },
                        onToggleCompare = {
                            viewModel.repository.toggleProductComparison(it)
                            showComparisonDialog = true
                        },
                        onOpenSayadCalc = { viewModel.openSayadCalculator(it) },
                        onNavigateToCategory = {
                            viewModel.selectCategory(it)
                            viewModel.navigateTo(AppScreen.CATALOG_FILTER)
                        },
                        onNavigateToBlog = { viewModel.navigateTo(AppScreen.BLOG_VIDEO) },
                        onOpenAiConsultant = { viewModel.openAiConsultant() }
                    )
                }

                AppScreen.CATALOG_FILTER -> {
                    CategoryCatalogScreen(
                        products = products,
                        searchQuery = searchQuery,
                        selectedCategory = selectedCategory,
                        inStockOnly = inStockOnly,
                        discountOnly = discountOnly,
                        installmentOnly = installmentOnly,
                        sortOption = sortOption,
                        comparisonCount = comparisonList.size,
                        comparisonIds = comparisonList.map { it.id },
                        onSearchChange = { viewModel.onSearchQueryChange(it) },
                        onSelectCategory = { viewModel.selectCategory(it) },
                        onToggleInStock = { viewModel.setFilterInStockOnly(it) },
                        onToggleDiscount = { viewModel.setFilterDiscountOnly(it) },
                        onToggleInstallment = { viewModel.setFilterInstallmentOnly(it) },
                        onSortChange = { viewModel.setSortOption(it) },
                        onSelectProduct = { viewModel.selectProduct(it) },
                        onAddToCart = { viewModel.repository.addToCart(it) },
                        onToggleCompare = { viewModel.repository.toggleProductComparison(it) },
                        onOpenSayadCalc = { viewModel.openSayadCalculator(it) },
                        onOpenComparisonDialog = { showComparisonDialog = true }
                    )
                }

                AppScreen.COMPARE -> {
                    showComparisonDialog = true
                    viewModel.navigateTo(AppScreen.HOME)
                }

                AppScreen.BLOG_VIDEO -> {
                    BlogAndVideoScreen(
                        articles = articles,
                        allProducts = allProducts,
                        onAddToCart = { viewModel.repository.addToCart(it) },
                        onOpenProduct = { viewModel.selectProduct(it) }
                    )
                }

                AppScreen.SUPPORT_TICKETS -> {
                    SupportAndTicketsScreen(
                        tickets = tickets,
                        chatMessages = chatMessages,
                        onSendChatMessage = { viewModel.repository.sendUserChatMessage(it) },
                        onCreateTicket = { subject, dept, prio, msg ->
                            viewModel.repository.createTicket(subject, dept, prio, msg)
                        },
                        onReplyTicket = { tId, text ->
                            viewModel.repository.replyToTicket(tId, text, isSupport = false)
                        }
                    )
                }

                AppScreen.PROFILE_ORDERS -> {
                    ProfileAndOrdersScreen(
                        orders = orders,
                        notifications = notifications,
                        onTrackOrder = { viewModel.trackOrder(it) }
                    )
                }

                AppScreen.ADMIN -> {
                    AdminPanelScreen(
                        products = allProducts,
                        orders = orders,
                        tickets = tickets,
                        onAddProduct = { viewModel.repository.addProduct(it) },
                        onDeleteProduct = { viewModel.repository.deleteProduct(it) },
                        onUpdateOrderStatus = { oId, st -> viewModel.repository.updateOrderStatus(oId, st) },
                        onAddArticle = { viewModel.repository.addArticle(it) },
                        onReplyTicket = { tId, text -> viewModel.repository.replyToTicket(tId, text, isSupport = true) }
                    )
                }
            }
        }
    }

    // Modal: Product Detail Sheet
    selectedProduct?.let { product ->
        ProductDetailSheet(
            product = product,
            reviews = product.reviews,
            isInComparison = comparisonList.any { it.id == product.id },
            onDismiss = { viewModel.selectProduct(null) },
            onAddToCart = { viewModel.repository.addToCart(it) },
            onToggleCompare = {
                viewModel.repository.toggleProductComparison(product)
                showComparisonDialog = true
            },
            onOpenSayadCalc = {
                viewModel.selectProduct(null)
                viewModel.openSayadCalculator(it)
            }
        )
    }

    // Modal: Sayad Cheques & Installment Calculator
    if (showSayadCalc) {
        val calcResult = viewModel.getSayadCalculation()
        SayadCalculatorDialog(
            baseAmount = calcBaseAmount,
            selectedMonths = calcMonths,
            downPaymentPercent = calcDownPayment,
            onMonthsChange = { viewModel.setCalcMonths(it) },
            onDownPaymentChange = { viewModel.setCalcDownPaymentPercent(it) },
            onDismiss = { viewModel.closeSayadCalculator() },
            calculationResult = calcResult,
            onProceedToInstallmentCheckout = {
                viewModel.closeSayadCalculator()
                viewModel.openCheckout(isInstallment = true)
            }
        )
    }

    // Modal: Cart Sheet
    if (showCartSheet) {
        CartSheet(
            cartItems = cartItems,
            appliedCouponCode = appliedCoupon,
            discountPercent = discountPercent,
            onUpdateQuantity = { id, delta -> viewModel.repository.updateCartQuantity(id, delta) },
            onRemoveItem = { viewModel.repository.removeFromCart(it) },
            onApplyCoupon = { viewModel.repository.applyCoupon(it) },
            onRemoveCoupon = { viewModel.repository.removeCoupon() },
            onDismiss = {
                showCartSheet = false
                if (cartItems.isNotEmpty() && appliedCoupon == null) {
                    viewModel.triggerExitPopup()
                }
            },
            onProceedToCheckout = { isInstallment ->
                showCartSheet = false
                viewModel.openCheckout(isInstallment = isInstallment)
            }
        )
    }

    // Modal: Online Payment Gateway Simulation (Shaparak)
    if (showCheckout) {
        val rawTotal = cartItems.sumOf { it.product.price * it.quantity }
        val discount = if (discountPercent > 0) (rawTotal * discountPercent) / 100 else 0L
        val payable = (rawTotal - discount).coerceAtLeast(0)

        PaymentGatewaySheet(
            cartItems = cartItems,
            payableAmount = payable,
            discountAmount = discount,
            isInstallment = isInstallmentCheckout,
            selectedGateway = selectedGateway,
            onGatewaySelect = { viewModel.selectGateway(it) },
            onDismiss = { viewModel.closeCheckout() },
            onConfirmPayment = { address, name, phone ->
                viewModel.processPayment(address, name, phone)
            }
        )
    }

    // Modal: Payment Success Official Receipt
    paymentSuccessOrder?.let { order ->
        PaymentSuccessReceiptDialog(
            order = order,
            onDismiss = { viewModel.clearPaymentSuccessOrder() },
            onTrackOrder = {
                viewModel.clearPaymentSuccessOrder()
                viewModel.navigateTo(AppScreen.PROFILE_ORDERS)
            }
        )
    }

    // Modal: Technical Product Comparison
    if (showComparisonDialog) {
        ProductComparisonDialog(
            products = comparisonList,
            onDismiss = { showComparisonDialog = false },
            onRemoveProduct = { viewModel.repository.toggleProductComparison(it) },
            onAddToCart = { viewModel.repository.addToCart(it) },
            onClearAll = { viewModel.repository.clearComparison() }
        )
    }

    // Modal: AI Pharmacist Consultant Sheet
    if (showAiConsultant) {
        AiPharmacistConsultantSheet(
            messages = chatMessages,
            allProducts = allProducts,
            onSendMessage = { viewModel.repository.sendUserChatMessage(it) },
            onAddToCart = { viewModel.repository.addToCart(it) },
            onDismiss = { viewModel.closeAiConsultant() }
        )
    }

    // Modal: Exit-Intent Discount Voucher Popup
    if (showExitPopup) {
        ExitDiscountDialog(
            onDismiss = { viewModel.repository.dismissExitDiscountPopup() },
            onApplyDiscount = { code ->
                viewModel.repository.applyCoupon(code)
                showCartSheet = true
            }
        )
    }
}
