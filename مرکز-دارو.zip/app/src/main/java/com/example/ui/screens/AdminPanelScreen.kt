package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.ui.components.formatTomans
import com.example.ui.theme.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    products: List<Product>,
    orders: List<Order>,
    tickets: List<SupportTicket>,
    onAddProduct: (Product) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onUpdateOrderStatus: (String, OrderStatus) -> Unit,
    onAddArticle: (HealthArticle) -> Unit,
    onReplyTicket: (String, String) -> Unit
) {
    var adminTab by remember { mutableStateOf(0) }

    // New Product form fields
    var newTitle by remember { mutableStateOf("") }
    var newGenericName by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf(ProductCategory.SUPPLEMENTS) }
    var newPrice by remember { mutableStateOf("385000") }
    var newDiscountPercent by remember { mutableStateOf("10") }
    var newBrand by remember { mutableStateOf("یوروویتال") }
    var newDosageForm by remember { mutableStateOf("کپسول") }
    var newIngredients by remember { mutableStateOf("زینک، ویتامین C، ویتامین B6") }
    var newDescription by remember { mutableStateOf("تقویت موثر سیستم ایمنی و حفظ سلامت پوست و مو") }
    var newIsInstallment by remember { mutableStateOf(true) }
    var productAddedSuccess by remember { mutableStateOf(false) }

    // New Video form fields
    var newVideoTitle by remember { mutableStateOf("") }
    var newVideoDuration by remember { mutableStateOf("04:30") }
    var newVideoAuthor by remember { mutableStateOf("دکتر مریم امینی (متخصص داروسازی)") }
    var newVideoSummary by remember { mutableStateOf("") }
    var videoAddedSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_panel_screen")
    ) {
        // Admin Header Banner
        Surface(
            color = MedicalGreenDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, tint = AmberDiscount)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "داشبورد مدیریت پیشرفته مرکز دارو",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Surface(
                    color = AmberDiscountContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "مدیر کل داروخانه",
                        color = AmberDiscount,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        // Stats Counter Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminStatCard(
                title = "فروش کل",
                value = formatTomans(orders.sumOf { it.payableAmount }),
                icon = Icons.Default.MonetizationOn,
                color = SuccessGreen,
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                title = "سفارشات",
                value = "${orders.size} عدد",
                icon = Icons.Default.LocalShipping,
                color = SoftBluePrimary,
                modifier = Modifier.weight(1f)
            )
            AdminStatCard(
                title = "تیکت‌ها",
                value = "${tickets.count { it.status == TicketStatus.OPEN }} باز",
                icon = Icons.Default.ConfirmationNumber,
                color = AmberDiscount,
                modifier = Modifier.weight(1f)
            )
        }

        // Admin Sub-tabs
        TabRow(
            selectedTabIndex = adminTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MedicalGreenPrimary
        ) {
            Tab(
                selected = adminTab == 0,
                onClick = { adminTab = 0 },
                text = { Text("سفارشات (${orders.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 1,
                onClick = { adminTab = 1 },
                text = { Text("انتشار محصول", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 2,
                onClick = { adminTab = 2 },
                text = { Text("انتشار ویدیو", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = adminTab == 3,
                onClick = { adminTab = 3 },
                text = { Text("کاتالوگ (${products.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            )
        }

        when (adminTab) {
            0 -> {
                // Orders Management: Change status
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(14.dp, 14.dp, 14.dp, 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(orders) { order ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(order.trackingCode, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoftBluePrimary)
                                    Text(formatTomans(order.payableAmount), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = MedicalGreenDark)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("گیرنده: ${order.recipientName} - ${order.recipientPhone}", fontSize = 11.sp)
                                Text("آدرس: ${order.shippingAddress}", fontSize = 10.sp, color = TextSecondaryMuted)

                                Spacer(modifier = Modifier.height(8.dp))
                                Text("تغییر وضعیت مرحله‌ای سفارش:", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    OrderStatus.values().forEach { st ->
                                        val isCurrent = order.status == st
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { onUpdateOrderStatus(order.id, st) },
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isCurrent) MedicalGreenPrimary else MedicalSurfaceVariant
                                        ) {
                                            Text(
                                                text = st.titleFa,
                                                fontSize = 9.sp,
                                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isCurrent) Color.White else TextPrimaryDark,
                                                modifier = Modifier.padding(vertical = 6.dp),
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Publish Product Form (انتشار محصول)
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(14.dp, 14.dp, 14.dp, 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("فرم انتشار محصول جدید در داروخانه:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    item {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("نام فارسی محصول دارویی / مکمل", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = newGenericName,
                            onValueChange = { newGenericName = it },
                            label = { Text("نام علمی / ژنریک انگلیسی", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newPrice,
                                onValueChange = { newPrice = it },
                                label = { Text("قیمت نهایی (تومان)", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = newDiscountPercent,
                                onValueChange = { newDiscountPercent = it },
                                label = { Text("درصد تخفیف", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newBrand,
                                onValueChange = { newBrand = it },
                                label = { Text("برند / کمپانی", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = newDosageForm,
                                onValueChange = { newDosageForm = it },
                                label = { Text("فرم دارویی (قرص، کپسول، شربت)", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = newIngredients,
                            onValueChange = { newIngredients = it },
                            label = { Text("ترکیبات فعال دارویی", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = newDescription,
                            onValueChange = { newDescription = it },
                            label = { Text("توضیحات و خواص درمانی", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = newIsInstallment, onCheckedChange = { newIsInstallment = it })
                            Text("امکان خرید اقساطی با چک صیادی", fontSize = 12.sp)
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                if (newTitle.isNotBlank()) {
                                    val priceLong = newPrice.toLongOrNull() ?: 300000L
                                    val discInt = newDiscountPercent.toIntOrNull() ?: 0
                                    val origPrice = if (discInt > 0) (priceLong * 100) / (100 - discInt) else priceLong

                                    val prod = Product(
                                        id = "prod-${UUID.randomUUID().toString().take(6)}",
                                        title = newTitle,
                                        genericName = if (newGenericName.isNotBlank()) newGenericName else newTitle,
                                        brand = newBrand,
                                        price = priceLong,
                                        originalPrice = origPrice,
                                        discountPercent = discInt,
                                        category = newCategory,
                                        inStock = true,
                                        rating = 4.8f,
                                        reviewCount = 1,
                                        isPrescriptionRequired = false,
                                        isInstallmentEligible = newIsInstallment,
                                        dosageForm = newDosageForm,
                                        activeIngredients = newIngredients,
                                        country = "ایران",
                                        description = newDescription,
                                        usageInstruction = "طبق دستور پزشک یا داروساز مصرف شود.",
                                        warnings = "دور از دسترس اطفال نگهداری شود."
                                    )
                                    onAddProduct(prod)
                                    productAddedSuccess = true
                                    newTitle = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                        ) {
                            Icon(imageVector = Icons.Default.Publish, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("انتشار رسمی محصول در فروشگاه", fontWeight = FontWeight.Bold)
                        }

                        if (productAddedSuccess) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("✅ محصول با موفقیت در کاتالوگ منتشر شد!", color = SuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            2 -> {
                // Publish Video Form (انتشار ویدیو)
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(14.dp, 14.dp, 14.dp, 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("فرم انتشار ویدیو و آموزش تخصصی داروساز:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    item {
                        OutlinedTextField(
                            value = newVideoTitle,
                            onValueChange = { newVideoTitle = it },
                            label = { Text("عنوان ویدیو آموزشی سلامت", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = newVideoAuthor,
                            onValueChange = { newVideoAuthor = it },
                            label = { Text("نام داروساز / متخصص مجری", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = newVideoDuration,
                            onValueChange = { newVideoDuration = it },
                            label = { Text("مدت زمان ویدیو (مثال: ۰۵:۲۰)", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = newVideoSummary,
                            onValueChange = { newVideoSummary = it },
                            label = { Text("خلاصه نکات ویدیو برای مخاطبین", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    item {
                        Button(
                            onClick = {
                                if (newVideoTitle.isNotBlank()) {
                                    val article = HealthArticle(
                                        id = "art-vid-${UUID.randomUUID().toString().take(6)}",
                                        title = newVideoTitle,
                                        category = "ویدیو آموزشی",
                                        author = newVideoAuthor,
                                        datePersian = "امروز",
                                        readingTime = newVideoDuration,
                                        summary = if (newVideoSummary.isNotBlank()) newVideoSummary else "آموزش تصویری تخصصی سلامت توسط داروسازان مرکز دارو",
                                        content = newVideoSummary,
                                        hasVideo = true,
                                        videoTitle = newVideoTitle,
                                        videoDuration = newVideoDuration,
                                        keyTakeaways = listOf("آموزش نحوه مصرف صحیح", "پایش اثربخشی درمان"),
                                        relatedProductIds = listOf("p-101", "p-103")
                                    )
                                    onAddArticle(article)
                                    videoAddedSuccess = true
                                    newVideoTitle = ""
                                    newVideoSummary = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SoftBluePrimary)
                        ) {
                            Icon(imageVector = Icons.Default.VideoCall, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("انتشار ویدیو در بخش آموزش سلامت", fontWeight = FontWeight.Bold)
                        }

                        if (videoAddedSuccess) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("✅ ویدیو آموزشی با موفقیت در بلاگ سلامت منتشر شد!", color = SuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            3 -> {
                // Products list with delete
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(14.dp, 14.dp, 14.dp, 80.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(products) { prod ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(10.dp),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("${formatTomans(prod.price)} - ${prod.brand}", fontSize = 10.sp, color = TextSecondaryMuted)
                                }
                                IconButton(onClick = { onDeleteProduct(prod.id) }, modifier = Modifier.size(30.dp)) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف کالا", tint = RoseDiscount)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = title, fontSize = 9.sp, color = TextSecondaryMuted)
            Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimaryDark, maxLines = 1)
        }
    }
}
