package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.CartItem
import com.example.data.models.Order
import com.example.ui.theme.*

val bankingGateways = listOf(
    "درگاه پرداخت سامان (سپ)",
    "درگاه به‌پرداخت ملت",
    "درگاه هوشمند زرین‌پال",
    "درگاه پارسیان (تاپ)"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentGatewaySheet(
    cartItems: List<CartItem>,
    payableAmount: Long,
    discountAmount: Long,
    isInstallment: Boolean,
    selectedGateway: String,
    onGatewaySelect: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirmPayment: (address: String, name: String, phone: String) -> Unit
) {
    var recipientName by remember { mutableStateOf("علی لطیفی") }
    var recipientPhone by remember { mutableStateOf("09123456789") }
    var shippingAddress by remember { mutableStateOf("تهران، خیابان ولیعصر، بالاتر از پارک ساعی، کوچه گلستان، پلاک ۱۸، واحد ۴") }
    
    var cardNumber by remember { mutableStateOf("۶۱۰۴ - ۳۳۷۸ - ۴۹۱۵ - ۸۲۹۰") }
    var cvv2 by remember { mutableStateOf("۳۴۸") }
    var expMonth by remember { mutableStateOf("۰۸") }
    var expYear by remember { mutableStateOf("۰۷") }
    var dynamicOtp by remember { mutableStateOf("۸۴۹۲۰۵") }
    var otpRequested by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .testTag("payment_gateway_dialog"),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header: Shaparak & Bank Security
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MedicalGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MedicalGreenDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "درگاه پرداخت امن شاپرک",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MedicalGreenDark
                            )
                            Text(
                                text = "اتصال رمزنگاری‌شده بانکی SSL",
                                fontSize = 10.sp,
                                color = TextSecondaryMuted
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "بستن")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Gateway Selection
                    item {
                        Text(
                            text = "انتخاب درگاه بانکی شتاب:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            bankingGateways.forEach { gateway ->
                                val isSelected = selectedGateway == gateway
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onGatewaySelect(gateway) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MedicalGreenContainer else MaterialTheme.colorScheme.surface,
                                    border = if (isSelected)
                                        androidx.compose.foundation.BorderStroke(1.5.dp, MedicalGreenPrimary)
                                    else
                                        ButtonDefaults.outlinedButtonBorder
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = { onGatewaySelect(gateway) },
                                                colors = RadioButtonDefaults.colors(selectedColor = MedicalGreenPrimary)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = gateway,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = TextPrimaryDark
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.VerifiedUser,
                                            contentDescription = null,
                                            tint = if (isSelected) MedicalGreenPrimary else TextTertiary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Order Price Summary
                    item {
                        Surface(
                            color = SoftBlueContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("تعداد اقلام سبد:", fontSize = 11.sp, color = TextSecondaryMuted)
                                    Text("${cartItems.sumOf { it.quantity }} عدد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                if (discountAmount > 0) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("تخفیف اعمال‌شده:", fontSize = 11.sp, color = RoseDiscount)
                                        Text("${formatTomans(discountAmount)}-", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RoseDiscount)
                                    }
                                }
                                Divider(color = SoftBlueLight)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (isInstallment) "پیش‌پرداخت نقدی اقساط:" else "مبلغ قابل پرداخت:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = formatTomans(payableAmount),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MedicalGreenDark
                                    )
                                }
                            }
                        }
                    }

                    // Recipient and Delivery Info
                    item {
                        Text(
                            text = "اطلاعات تحویل‌گیرنده و آدرس ارسال:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = recipientName,
                            onValueChange = { recipientName = it },
                            label = { Text("نام و نام خانوادگی", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = recipientPhone,
                            onValueChange = { recipientPhone = it },
                            label = { Text("شماره تماس هماهنگی", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = shippingAddress,
                            onValueChange = { shippingAddress = it },
                            label = { Text("نشانی دقیق پستی تحویل دارو و کالا", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 2,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Card Information Inputs (Shaparak simulation)
                    item {
                        Text(
                            text = "اطلاعات کارت بانکی پرداخت‌کننده:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { cardNumber = it },
                            label = { Text("شماره ۱۶ رقمی کارت بانکی", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = MedicalGreenPrimary)
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = cvv2,
                                onValueChange = { cvv2 = it },
                                label = { Text("کد CVV2", fontSize = 10.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = expMonth,
                                onValueChange = { expMonth = it },
                                label = { Text("ماه انقضا", fontSize = 10.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = expYear,
                                onValueChange = { expYear = it },
                                label = { Text("سال انقضا", fontSize = 10.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Dynamic OTP SMS Section
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = dynamicOtp,
                                onValueChange = { dynamicOtp = it },
                                label = { Text("رمز پویا پیامکی", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp)
                            )
                            Button(
                                onClick = { otpRequested = true },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (otpRequested) SuccessGreen else SoftBluePrimary
                                )
                            ) {
                                Text(
                                    text = if (otpRequested) "ارسال مجدد (۵۴s)" else "دریافت رمز پویا",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Pay Button
                Button(
                    onClick = {
                        isProcessing = true
                        onConfirmPayment(shippingAddress, recipientName, recipientPhone)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_payment_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
                    } else {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تایید و پرداخت امن شاپرک (${formatTomans(payableAmount)})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentSuccessReceiptDialog(
    order: Order,
    onDismiss: () -> Unit,
    onTrackOrder: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("payment_success_receipt")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(SuccessGreen.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "پرداخت با موفقیت انجام شد",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MedicalGreenDark
                )

                Text(
                    text = "فاکتور الکترونیکی سفارش مرکز دارو",
                    fontSize = 11.sp,
                    color = TextSecondaryMuted
                )

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    color = MedicalSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("کد پیگیری شاپرک:", fontSize = 11.sp, color = TextSecondaryMuted)
                            Text(order.trackingCode, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoftBluePrimary)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("مبلغ تراکنش:", fontSize = 11.sp, color = TextSecondaryMuted)
                            Text(formatTomans(order.payableAmount), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MedicalGreenDark)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("درگاه بانکی:", fontSize = 11.sp, color = TextSecondaryMuted)
                            Text(order.paymentGateway, fontSize = 11.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("گیرنده:", fontSize = 11.sp, color = TextSecondaryMuted)
                            Text(order.recipientName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("وضعیت سفارش:", fontSize = 11.sp, color = TextSecondaryMuted)
                            Text(order.status.titleFa, fontSize = 11.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onTrackOrder,
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                ) {
                    Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("مشاهده مراحل و پیگیری زنده سفارش", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("بستن فاکتور و بازگشت به فروشگاه", fontSize = 12.sp)
                }
            }
        }
    }
}
