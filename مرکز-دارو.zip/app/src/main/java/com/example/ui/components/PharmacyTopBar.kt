package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CartItem
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyTopBar(
    cartItems: List<CartItem>,
    unreadNotificationCount: Int,
    currentScreen: AppScreen,
    onNavigate: (AppScreen) -> Unit,
    onOpenCart: () -> Unit,
    onOpenAiConsultant: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Header with Icon & Persian Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onNavigate(AppScreen.HOME) }
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MedicalGreenPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalPharmacy,
                            contentDescription = "مرکز دارو",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "مرکز دارو",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MedicalGreenDark,
                                    fontSize = 20.sp
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = SoftBlueContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "داروخانه آنلاین",
                                    color = OnSoftBlueContainer,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "آرامش و سلامت با اصالت تضمینی",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondaryMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Action Icons (AI, Notifications, Cart, Admin)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // AI Consultant Button
                    IconButton(
                        onClick = onOpenAiConsultant,
                        modifier = Modifier
                            .testTag("ai_consultant_button")
                            .size(40.dp)
                    ) {
                        Surface(
                            color = SoftBlueContainer,
                            shape = CircleShape,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "مشاور هوش مصنوعی",
                                    tint = SoftBluePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Notifications Button
                    IconButton(
                        onClick = { onNavigate(AppScreen.PROFILE_ORDERS) },
                        modifier = Modifier.size(40.dp)
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotificationCount > 0) {
                                    Badge(
                                        containerColor = RoseDiscount,
                                        contentColor = Color.White
                                    ) {
                                        Text(text = "$unreadNotificationCount", fontSize = 10.sp)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "اعلان‌ها",
                                tint = TextPrimaryDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Cart Button
                    IconButton(
                        onClick = onOpenCart,
                        modifier = Modifier
                            .testTag("cart_top_button")
                            .size(40.dp)
                    ) {
                        val cartCount = cartItems.sumOf { it.quantity }
                        BadgedBox(
                            badge = {
                                if (cartCount > 0) {
                                    Badge(
                                        containerColor = MedicalGreenPrimary,
                                        contentColor = Color.White
                                    ) {
                                        Text(text = "$cartCount", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingCart,
                                contentDescription = "سبد خرید",
                                tint = TextPrimaryDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Admin Switch
                    IconButton(
                        onClick = {
                            if (currentScreen == AppScreen.ADMIN) {
                                onNavigate(AppScreen.HOME)
                            } else {
                                onNavigate(AppScreen.ADMIN)
                            }
                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.ADMIN) Icons.Filled.Storefront else Icons.Outlined.AdminPanelSettings,
                            contentDescription = "پنل مدیریت",
                            tint = if (currentScreen == AppScreen.ADMIN) AmberDiscount else TextSecondaryMuted
                        )
                    }
                }
            }
        }
    }
}
