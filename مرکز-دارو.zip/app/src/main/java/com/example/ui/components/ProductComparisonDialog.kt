package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.Product
import com.example.ui.theme.*

@Composable
fun ProductComparisonDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onRemoveProduct: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onClearAll: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .testTag("product_comparison_dialog"),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MedicalGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CompareArrows,
                                contentDescription = null,
                                tint = MedicalGreenDark,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "مقایسه فنی کالاها (${products.size} محصول)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "بررسی ترکیبات فعال، دوز و مشخصات فنی",
                                fontSize = 10.sp,
                                color = TextSecondaryMuted
                            )
                        }
                    }

                    Row {
                        if (products.isNotEmpty()) {
                            IconButton(onClick = onClearAll, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "پاک کردن همه",
                                    tint = RoseDiscount,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "بستن")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (products.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.CompareArrows,
                                contentDescription = null,
                                tint = TextTertiary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "هنوز کالایی به لیست مقایسه اضافه نکرده‌اید",
                                fontSize = 13.sp,
                                color = TextSecondaryMuted
                            )
                            Text(
                                text = "روی آیکون مقایسه در کارت محصولات کلیک کنید",
                                fontSize = 11.sp,
                                color = TextTertiary
                            )
                        }
                    }
                } else {
                    // Comparison Table with Horizontal Scroll
                    val horizontalScroll = rememberScrollState()
                    val verticalScroll = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(verticalScroll)
                            .horizontalScroll(horizontalScroll)
                    ) {
                        // Product Headers Row
                        Row(modifier = Modifier.padding(bottom = 12.dp)) {
                            // Column label spacer
                            Box(modifier = Modifier.width(100.dp))
                            products.forEach { prod ->
                                Card(
                                    modifier = Modifier
                                        .width(180.dp)
                                        .padding(horizontal = 4.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MedicalSurfaceVariant)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            IconButton(
                                                onClick = { onRemoveProduct(prod) },
                                                modifier = Modifier.size(22.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "حذف",
                                                    tint = TextTertiary,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = prod.title,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 2,
                                            color = TextPrimaryDark
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = formatTomans(prod.price),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MedicalGreenDark
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Button(
                                            onClick = { onAddToCart(prod) },
                                            modifier = Modifier.fillMaxWidth().height(32.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("افزودن به سبد", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        Divider(color = OutlineBorder.copy(alpha = 0.5f))

                        // Metric Rows
                        ComparisonRow("برند و سازنده", products) { it.brand }
                        ComparisonRow("کشور مبدا", products) { it.country }
                        ComparisonRow("فرم و شکل دارویی", products) { it.dosageForm }
                        ComparisonRow("ترکیبات فعال اصلی", products) { it.activeIngredients }
                        ComparisonRow("خرید اقساطی صیادی", products) {
                            if (it.isInstallmentEligible) "✅ مجاز (تا ۲۴ ماه)" else "❌ نقدی"
                        }
                        ComparisonRow("نیاز به نسخه پزشک", products) {
                            if (it.isPrescriptionRequired) "⚠️ نیاز به نسخه" else "✔️ بدون نیاز به نسخه (OTC)"
                        }
                        ComparisonRow("امتیاز خریداران", products) { "⭐ ${it.rating} از ۵ (${it.reviewCount} نظر)" }
                        ComparisonRow("دستور مصرف خلاصه", products) { it.usageInstruction }
                    }
                }
            }
        }
    }
}

@Composable
fun ComparisonRow(
    label: String,
    products: List<Product>,
    valueExtractor: (Product) -> String
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondaryMuted,
                modifier = Modifier.width(100.dp).padding(end = 6.dp)
            )

            products.forEach { prod ->
                Surface(
                    color = MedicalSurfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .width(180.dp)
                        .padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = valueExtractor(prod),
                        fontSize = 10.sp,
                        color = TextPrimaryDark,
                        lineHeight = 14.sp,
                        modifier = Modifier.padding(8.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
    Divider(color = OutlineBorder.copy(alpha = 0.3f))
}
