package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.HealthArticle
import com.example.data.models.Product
import com.example.data.models.ProductCategory
import com.example.ui.components.ProductCard
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen

@Composable
fun HomeScreen(
    products: List<Product>,
    articles: List<HealthArticle>,
    comparisonIds: List<String>,
    onSelectProduct: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleCompare: (Product) -> Unit,
    onOpenSayadCalc: (Long) -> Unit,
    onNavigateToCategory: (ProductCategory) -> Unit,
    onNavigateToBlog: () -> Unit,
    onOpenAiConsultant: () -> Unit
) {
    var bannerIndex by remember { mutableStateOf(0) }

    val banners = listOf(
        BannerData(
            title = "جشنواره بهاره مکمل‌های ورزشی و پروتئین",
            subtitle = "تا ۲۰٪ تخفیف ویژه + امکان خرید اقساطی با چک صیادی",
            gradient = listOf(MedicalGreenPrimary, MedicalGreenDark),
            icon = Icons.Default.FitnessCenter,
            category = ProductCategory.SUPPLEMENTS
        ),
        BannerData(
            title = "پایش هوشمند فشار و قند خون در خانه",
            subtitle = "تجهیزات پزشکی اصل با گارانتی تعویض و خدمات پس از فروش",
            gradient = listOf(SoftBluePrimary, Color(0xFF0369A1)),
            icon = Icons.Default.MonitorHeart,
            category = ProductCategory.MEDICAL_EQUIPMENT
        ),
        BannerData(
            title = "مشاوره دارویی آنلاین با دکتر داروساز هوش مصنوعی",
            subtitle = "پاسخگویی آنی به تداخلات دارویی و رژیم‌های درمانی",
            gradient = listOf(Color(0xFF0F766E), Color(0xFF115E59)),
            icon = Icons.Default.AutoAwesome,
            category = ProductCategory.ALL
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Sliding Banner Section (بنر اسلایدی)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                val currentBanner = banners[bannerIndex]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clickable {
                            if (currentBanner.category == ProductCategory.ALL) {
                                onOpenAiConsultant()
                            } else {
                                onNavigateToCategory(currentBanner.category)
                            }
                        },
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.linearGradient(currentBanner.gradient))
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    color = Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "پیشنهاد طلایی مرکز دارو",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = currentBanner.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    lineHeight = 20.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = currentBanner.subtitle,
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.9f),
                                    lineHeight = 16.sp
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = currentBanner.icon,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Banner Indicators (Dots)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    banners.indices.forEach { index ->
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .size(if (index == bannerIndex) 20.dp else 8.dp, 8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (index == bannerIndex) MedicalGreenPrimary else OutlineBorder)
                                .clickable { bannerIndex = index }
                        )
                    }
                }
            }
        }

        // Quick Category Chips
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "دسته‌بندی‌های دارویی و تخصصی:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimaryDark,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(ProductCategory.values().filter { it != ProductCategory.ALL }) { cat ->
                        Surface(
                            color = MedicalSurfaceVariant,
                            shape = RoundedCornerShape(14.dp),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.clickable { onNavigateToCategory(cat) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (cat) {
                                        ProductCategory.MEDICINE -> Icons.Default.Medication
                                        ProductCategory.SUPPLEMENTS -> Icons.Default.FitnessCenter
                                        ProductCategory.MEDICAL_EQUIPMENT -> Icons.Default.MonitorHeart
                                        ProductCategory.DERMO_COSMETIC -> Icons.Default.Spa
                                        ProductCategory.MOTHER_AND_BABY -> Icons.Default.ChildCare
                                        else -> Icons.Default.LocalPharmacy
                                    },
                                    contentDescription = null,
                                    tint = MedicalGreenPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = cat.persianTitle,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark
                                )
                            }
                        }
                    }
                }
            }
        }

        // AI Smart Advisor Prompt Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onOpenAiConsultant() },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SoftBlueContainer.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, SoftBlueLight)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(SoftBluePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مشاور هوشمند داروساز مرکز دارو",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = OnSoftBlueContainer
                        )
                        Text(
                            text = "تحلیل علائم شما و پیشنهاد پکیج مکمل متناسب با سبک زندگی",
                            fontSize = 11.sp,
                            color = TextSecondaryMuted
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = null,
                        tint = SoftBluePrimary
                    )
                }
            }
        }

        // Special Flash Deals Header (تخفیف ویژه روزانه با شمارش معکوس)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = null,
                            tint = RoseDiscount
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تخفیف‌های شگفت‌انگیز ویژه روز",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark
                        )
                    }

                    Surface(
                        color = RoseContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Timer, contentDescription = null, tint = RoseDiscount, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "۰۴:۲۵:۱۸ باقی‌مانده",
                                color = RoseDiscount,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Flash Deals Carousel
        item {
            val discounted = products.filter { it.discountPercent > 0 }
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp)
            ) {
                items(discounted) { prod ->
                    ProductCard(
                        product = prod,
                        isInComparison = comparisonIds.contains(prod.id),
                        onProductClick = { onSelectProduct(prod) },
                        onAddToCart = { onAddToCart(prod) },
                        onToggleCompare = { onToggleCompare(prod) },
                        onOpenInstallmentCalc = { onOpenSayadCalc(prod.price) },
                        modifier = Modifier.width(220.dp)
                    )
                }
            }
        }

        // Sayad Installment Feature Highlight Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MedicalGreenContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خرید آسان با چک‌های صیادی بنفش",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MedicalGreenDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "تجهیزات پزشکی گران‌قیمت و مکمل‌ها را در اقساط ۳ تا ۲۴ ماهه با اعتبارسنجی آنلاین بانک مرکزی تهیه کنید.",
                            fontSize = 11.sp,
                            color = OnMedicalGreenContainer,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { onOpenSayadCalc(4850000L) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenDark),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("محاسبه خودکار اقساط", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Icon(
                        imageVector = Icons.Default.AccountBalance,
                        contentDescription = null,
                        tint = MedicalGreenDark,
                        modifier = Modifier.size(54.dp)
                    )
                }
            }
        }

        // Health Blog and Video Preview Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null, tint = SoftBluePrimary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "بلاگ و ویدیوهای آموزشی سلامت",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryDark
                    )
                }

                TextButton(onClick = onNavigateToBlog) {
                    Text("مشاهده همه مقالات", fontSize = 11.sp, color = SoftBluePrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Blog Video Card
        item {
            val articleWithVideo = articles.firstOrNull { it.hasVideo } ?: articles.firstOrNull()
            if (articleWithVideo != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clickable { onNavigateToBlog() },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .background(Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF334155)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircleFilled,
                                contentDescription = "پخش ویدیو",
                                tint = Color.White,
                                modifier = Modifier.size(52.dp)
                            )
                            if (articleWithVideo.videoDuration != null) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = articleWithVideo.videoDuration,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = articleWithVideo.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = articleWithVideo.summary,
                                fontSize = 11.sp,
                                color = TextSecondaryMuted,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }
    }
}

data class BannerData(
    val title: String,
    val subtitle: String,
    val gradient: List<Color>,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val category: ProductCategory
)
