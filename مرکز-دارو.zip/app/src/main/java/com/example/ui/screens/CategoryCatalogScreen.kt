package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Product
import com.example.data.models.ProductCategory
import com.example.ui.components.ProductCard
import com.example.ui.theme.*
import com.example.viewmodel.SortOption

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryCatalogScreen(
    products: List<Product>,
    searchQuery: String,
    selectedCategory: ProductCategory,
    inStockOnly: Boolean,
    discountOnly: Boolean,
    installmentOnly: Boolean,
    sortOption: SortOption,
    comparisonCount: Int,
    comparisonIds: List<String>,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (ProductCategory) -> Unit,
    onToggleInStock: (Boolean) -> Unit,
    onToggleDiscount: (Boolean) -> Unit,
    onToggleInstallment: (Boolean) -> Unit,
    onSortChange: (SortOption) -> Unit,
    onSelectProduct: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleCompare: (Product) -> Unit,
    onOpenSayadCalc: (Long) -> Unit,
    onOpenComparisonDialog: () -> Unit
) {
    var showSortMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("category_catalog_screen")
    ) {
        // Search and Filter Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("جستجوی نام دارو، برند، ترکیب شیمیایی یا مکمل...", fontSize = 12.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("catalog_search_bar"),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "جستجو",
                        tint = MedicalGreenPrimary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "پاک کردن", tint = TextTertiary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Categories horizontal list
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ProductCategory.values()) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectCategory(cat) },
                        label = {
                            Text(
                                text = cat.persianTitle,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MedicalGreenPrimary,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Filters & Sort Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Filter Toggles
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        FilterChip(
                            selected = inStockOnly,
                            onClick = { onToggleInStock(!inStockOnly) },
                            label = { Text("موجود", fontSize = 10.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = discountOnly,
                            onClick = { onToggleDiscount(!discountOnly) },
                            label = { Text("تخفیف‌دار", fontSize = 10.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = installmentOnly,
                            onClick = { onToggleInstallment(!installmentOnly) },
                            label = { Text("اقساط صیادی", fontSize = 10.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                // Sort Dropdown Button
                Box {
                    IconButton(
                        onClick = { showSortMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "مرتب‌سازی",
                            tint = MedicalGreenDark
                        )
                    }
                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        SortOption.values().forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = option.titleFa,
                                        fontSize = 11.sp,
                                        fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal,
                                        color = if (sortOption == option) MedicalGreenDark else TextPrimaryDark
                                    )
                                },
                                onClick = {
                                    onSortChange(option)
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Divider(color = OutlineBorder.copy(alpha = 0.5f))

        // Comparison Floating Status Banner if items added
        if (comparisonCount > 0) {
            Surface(
                color = MedicalGreenContainer,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenComparisonDialog() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CompareArrows,
                            contentDescription = null,
                            tint = MedicalGreenDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$comparisonCount کالا در لیست مقایسه فنی",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MedicalGreenDark
                        )
                    }
                    Text(
                        text = "مشاهده جدول مقایسه >",
                        fontSize = 11.sp,
                        color = MedicalGreenDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Product Count Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${products.size} محصول یافت شد",
                fontSize = 12.sp,
                color = TextSecondaryMuted
            )
            Text(
                text = "مرتب‌سازی: ${sortOption.titleFa}",
                fontSize = 11.sp,
                color = TextTertiary
            )
        }

        // Product Grid (2 columns)
        if (products.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.SearchOff,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "کالایی با مشخصات مورد نظر شما یافت نشد",
                        fontSize = 13.sp,
                        color = TextSecondaryMuted
                    )
                    Text(
                        text = "فیلترها را تغییر داده یا از مشاوره هوشمند کمک بگیرید",
                        fontSize = 11.sp,
                        color = TextTertiary
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 80.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(products) { product ->
                    ProductCard(
                        product = product,
                        isInComparison = comparisonIds.contains(product.id),
                        onProductClick = { onSelectProduct(product) },
                        onAddToCart = { onAddToCart(product) },
                        onToggleCompare = { onToggleCompare(product) },
                        onOpenInstallmentCalc = { onOpenSayadCalc(product.price) }
                    )
                }
            }
        }
    }
}
