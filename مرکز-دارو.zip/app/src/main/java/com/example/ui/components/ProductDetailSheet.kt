package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.Product
import com.example.data.models.ProductReview
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailSheet(
    product: Product,
    reviews: List<ProductReview>,
    isInComparison: Boolean,
    onDismiss: () -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleCompare: () -> Unit,
    onOpenSayadCalc: (Long) -> Unit
) {
    var userRating by remember { mutableStateOf(5) }
    var userComment by remember { mutableStateOf("") }
    var localReviews by remember { mutableStateOf(reviews) }
    var showAddReviewDialog by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.94f)
                .testTag("product_detail_dialog"),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onToggleCompare, modifier = Modifier.size(36.dp)) {
                            Icon(
                                imageVector = if (isInComparison) Icons.Filled.CompareArrows else Icons.Outlined.CompareArrows,
                                contentDescription = "مقایسه",
                                tint = if (isInComparison) MedicalGreenPrimary else TextTertiary
                            )
                        }
                        if (product.isInstallmentEligible) {
                            IconButton(onClick = { onOpenSayadCalc(product.price) }, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    imageVector = Icons.Outlined.AccountBalanceWallet,
                                    contentDescription = "اقساط صیادی",
                                    tint = SoftBluePrimary
                                )
                            }
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "بستن")
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Visual Banner
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (product.category == com.example.data.models.ProductCategory.MEDICAL_EQUIPMENT)
                                        SoftBlueContainer.copy(alpha = 0.7f)
                                    else
                                        MedicalGreenContainer.copy(alpha = 0.7f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = when (product.category) {
                                        com.example.data.models.ProductCategory.MEDICINE -> Icons.Filled.Medication
                                        com.example.data.models.ProductCategory.SUPPLEMENTS -> Icons.Filled.FitnessCenter
                                        com.example.data.models.ProductCategory.MEDICAL_EQUIPMENT -> Icons.Filled.MonitorHeart
                                        com.example.data.models.ProductCategory.DERMO_COSMETIC -> Icons.Filled.Spa
                                        com.example.data.models.ProductCategory.MOTHER_AND_BABY -> Icons.Filled.ChildCare
                                        else -> Icons.Filled.LocalPharmacy
                                    },
                                    contentDescription = product.title,
                                    tint = if (product.category == com.example.data.models.ProductCategory.MEDICAL_EQUIPMENT)
                                        SoftBluePrimary
                                    else
                                        MedicalGreenPrimary,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "${product.brand} - ${product.country}",
                                    fontSize = 12.sp,
                                    color = TextSecondaryMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (product.discountPercent > 0) {
                                Surface(
                                    color = RoseDiscount,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = "${product.discountPercent}٪ تخفیف ویژه",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Titles & Metadata
                    item {
                        Text(
                            text = product.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = product.genericName,
                            fontSize = 11.sp,
                            color = TextTertiary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = MedicalSurfaceVariant,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "شکل: ${product.dosageForm}",
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                color = if (product.isPrescriptionRequired) RoseContainer else MedicalGreenContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (product.isPrescriptionRequired) "⚠️ نیاز به نسخه" else "✔️ بدون نیاز به نسخه (OTC)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (product.isPrescriptionRequired) RoseDiscount else MedicalGreenDark,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Price Card
                    item {
                        Surface(
                            color = MedicalSurfaceVariant,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("قیمت مصرف‌کننده:", fontSize = 11.sp, color = TextSecondaryMuted)
                                    if (product.discountPercent > 0) {
                                        Text(
                                            text = formatTomans(product.originalPrice),
                                            fontSize = 12.sp,
                                            color = TextTertiary,
                                            textDecoration = TextDecoration.LineThrough
                                        )
                                    }
                                    Text(
                                        text = formatTomans(product.price),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MedicalGreenDark
                                    )
                                }

                                if (product.isInstallmentEligible) {
                                    Button(
                                        onClick = { onOpenSayadCalc(product.price) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SoftBluePrimary)
                                    ) {
                                        Icon(imageVector = Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("خرید اقساطی صیادی", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Description
                    item {
                        Text("توضیحات و کاربرد دارویی:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = product.description,
                            fontSize = 12.sp,
                            color = TextSecondaryMuted,
                            lineHeight = 18.sp
                        )
                    }

                    // Active Ingredients
                    item {
                        Text("ترکیبات فعال و مشخصات فرمولاسیون:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = SoftBlueContainer.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = product.activeIngredients,
                                fontSize = 11.sp,
                                color = OnSoftBlueContainer,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // Usage Instructions & Warnings
                    item {
                        Text("راهنمای مصرف و هشدارهای داروساز:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = product.usageInstruction,
                            fontSize = 11.sp,
                            color = TextSecondaryMuted,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = AmberDiscountContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "احتیاط: ${product.warnings}",
                                fontSize = 10.sp,
                                color = AmberDiscount,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // Reviews Section Header & Add Review Button
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "دیدگاه و امتیاز خریداران (${localReviews.size}):",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            TextButton(onClick = { showAddReviewDialog = true }) {
                                Icon(imageVector = Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ثبت نظر جدید", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Review Items
                    items(localReviews) { review ->
                        Surface(
                            color = MedicalSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(review.author, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        if (review.isVerifiedBuyer) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = SuccessGreen.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "خریدار تاییدشده",
                                                    color = SuccessGreen,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Row {
                                        repeat(review.rating) {
                                            Icon(
                                                imageVector = Icons.Default.Star,
                                                contentDescription = null,
                                                tint = AmberDiscount,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(review.comment, fontSize = 11.sp, color = TextSecondaryMuted, lineHeight = 16.sp)

                                if (review.pros.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    review.pros.forEach { pro ->
                                        Text("✔️ $pro", fontSize = 10.sp, color = MedicalGreenDark)
                                    }
                                }
                                if (review.cons.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    review.cons.forEach { con ->
                                        Text("✖️ $con", fontSize = 10.sp, color = RoseDiscount)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Add to Cart Action
                Button(
                    onClick = {
                        onAddToCart(product)
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("sheet_add_to_cart_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                ) {
                    Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "افزودن به سبد خرید (${formatTomans(product.price)})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }

    // Add Review Dialog
    if (showAddReviewDialog) {
        Dialog(onDismissRequest = { showAddReviewDialog = false }) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ثبت نظر برای ${product.title}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row {
                        (1..5).forEach { star ->
                            IconButton(onClick = { userRating = star }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (star <= userRating) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = null,
                                    tint = AmberDiscount
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = userComment,
                        onValueChange = { userComment = it },
                        label = { Text("تجربه مصرف یا نظر شما...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            if (userComment.isNotBlank()) {
                                localReviews = listOf(
                                    ProductReview(
                                        id = "rev-${System.currentTimeMillis()}",
                                        author = "شما",
                                        rating = userRating,
                                        datePersian = "امروز",
                                        comment = userComment,
                                        isVerifiedBuyer = true
                                    )
                                ) + localReviews
                                userComment = ""
                                showAddReviewDialog = false
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ارسال دیدگاه")
                    }
                }
            }
        }
    }
}
