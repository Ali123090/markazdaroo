package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Product
import com.example.ui.theme.*
import java.text.DecimalFormat

val tomanFormatter = DecimalFormat("#,###")

fun formatTomans(amount: Long): String {
    return tomanFormatter.format(amount) + " تومان"
}

@Composable
fun ProductCard(
    product: Product,
    isInComparison: Boolean,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit,
    onToggleCompare: () -> Unit,
    onOpenInstallmentCalc: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag("product_card_${product.id}")
            .fillMaxWidth()
            .clickable { onProductClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header: Category Pill & Action Buttons (Compare & Installment)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Badge or Dosage Form
                if (product.badge != null) {
                    Surface(
                        color = AmberDiscountContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = product.badge,
                            color = AmberDiscount,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                } else {
                    Surface(
                        color = MedicalSurfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = product.dosageForm,
                            color = TextSecondaryMuted,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Compare Toggle
                    IconButton(
                        onClick = onToggleCompare,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isInComparison) Icons.Filled.CompareArrows else Icons.Outlined.CompareArrows,
                            contentDescription = "مقایسه کالا",
                            tint = if (isInComparison) MedicalGreenPrimary else TextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Installment indicator icon if eligible
                    if (product.isInstallmentEligible) {
                        IconButton(
                            onClick = onOpenInstallmentCalc,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AccountBalanceWallet,
                                contentDescription = "خرید اقساطی صیادی",
                                tint = SoftBluePrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Medical Visual Box (Stylized representation with gradient and medical vector)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (product.category == com.example.data.models.ProductCategory.MEDICAL_EQUIPMENT)
                            SoftBlueContainer.copy(alpha = 0.6f)
                        else
                            MedicalGreenContainer.copy(alpha = 0.6f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = when (product.category) {
                            com.example.data.models.ProductCategory.MEDICINE -> Icons.Filled.Medication
                            com.example.data.models.ProductCategory.SUPPLEMENTS -> Icons.Filled.FitnessCenter
                            com.example.data.models.ProductCategory.MEDICAL_EQUIPMENT -> Icons.Filled.MonitorHeart
                            com.example.data.models.ProductCategory.DERMO_COSMETIC -> Icons.Filled.Spa
                            com.example.data.models.ProductCategory.MOTHER_AND_BABY -> Icons.Filled.ChildCare
                            else -> Icons.Filled.LocalPharmacy
                        },
                        contentDescription = product.title,
                        tint = if (product.category == com.example.data.models.ProductCategory.MEDICAL_EQUIPMENT)
                            SoftBluePrimary
                        else
                            MedicalGreenPrimary,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.brand,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondaryMuted,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                // Discount percentage tag
                if (product.discountPercent > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(RoseDiscount)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${product.discountPercent}%-",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = product.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                ),
                color = TextPrimaryDark,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Generic English Name
            Text(
                text = product.genericName,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextTertiary,
                    fontSize = 10.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Rating & Review count
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = null,
                    tint = AmberDiscount,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${product.rating}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "(${product.reviewCount} نظر)",
                    fontSize = 10.sp,
                    color = TextTertiary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Price & Original Price
            Column {
                if (product.discountPercent > 0) {
                    Text(
                        text = formatTomans(product.originalPrice),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextTertiary,
                            fontSize = 11.sp,
                            textDecoration = TextDecoration.LineThrough
                        )
                    )
                }
                Text(
                    text = formatTomans(product.price),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = MedicalGreenDark,
                        fontSize = 14.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Installment tag if available
            if (product.isInstallmentEligible) {
                Surface(
                    color = SoftBlueContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().clickable { onOpenInstallmentCalc() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SoftBluePrimary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "اقساط تا ۲۴ ماه با چک صیاد",
                            color = OnSoftBlueContainer,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Quick Add to Cart Button
            Button(
                onClick = onAddToCart,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .testTag("add_to_cart_${product.id}"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MedicalGreenPrimary,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.AddShoppingCart,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "افزودن به سبد",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
