package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MedicalGreenLight,
    onPrimary = Color.Black,
    primaryContainer = MedicalGreenDark,
    onPrimaryContainer = MedicalGreenContainer,
    secondary = SoftBlueLight,
    onSecondary = Color.Black,
    secondaryContainer = SoftBluePrimary,
    onSecondaryContainer = Color.White,
    tertiary = AmberDiscount,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkCardSurface,
    onBackground = DarkTextPrimary,
    onSurface = DarkTextPrimary,
    outline = OutlineBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MedicalGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = MedicalGreenContainer,
    onPrimaryContainer = OnMedicalGreenContainer,
    secondary = SoftBluePrimary,
    onSecondary = Color.White,
    secondaryContainer = SoftBlueContainer,
    onSecondaryContainer = OnSoftBlueContainer,
    tertiary = AmberDiscount,
    background = MedicalSurfaceLight,
    surface = MedicalCardSurface,
    surfaceVariant = MedicalSurfaceVariant,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    outline = OutlineBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color so the brand medical green & soft blue always shine
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

