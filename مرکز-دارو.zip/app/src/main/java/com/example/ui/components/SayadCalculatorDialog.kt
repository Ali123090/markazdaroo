package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.SayadCalculationResult
import com.example.ui.theme.*

@Composable
fun SayadCalculatorDialog(
    baseAmount: Long,
    selectedMonths: Int,
    downPaymentPercent: Int,
    onMonthsChange: (Int) -> Unit,
    onDownPaymentChange: (Int) -> Unit,
    onDismiss: () -> Unit,
    calculationResult: SayadCalculationResult,
    onProceedToInstallmentCheckout: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .testTag("sayad_calculator_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SoftBlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = null,
                                tint = SoftBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "محاسبه‌گر چک‌های صیادی",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                ),
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "خرید اقساطی تجهیزات و مکمل‌ها",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondaryMuted,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "بستن")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        // Total Price Box
                        Surface(
                            color = MedicalSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "مبلغ کل خرید:",
                                    fontSize = 13.sp,
                                    color = TextSecondaryMuted
                                )
                                Text(
                                    text = formatTomans(baseAmount),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MedicalGreenDark
                                )
                            }
                        }
                    }

                    // Down Payment Percentage Selection
                    item {
                        Text(
                            text = "درصد پیش‌پرداخت نقدی:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(20, 25, 30, 50).forEach { percent ->
                                val isSelected = downPaymentPercent == percent
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onDownPaymentChange(percent) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MedicalGreenPrimary else MaterialTheme.colorScheme.surface,
                                    border = if (!isSelected) ButtonDefaults.outlinedButtonBorder else null
                                ) {
                                    Text(
                                        text = "$percent٪",
                                        color = if (isSelected) Color.White else TextPrimaryDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Months Selection
                    item {
                        Text(
                            text = "مدت زمان بازپرداخت (تعداد ماه‌ها):",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(3, 6, 12, 24).forEach { months ->
                                val isSelected = selectedMonths == months
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onMonthsChange(months) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) SoftBluePrimary else MaterialTheme.colorScheme.surface,
                                    border = if (!isSelected) ButtonDefaults.outlinedButtonBorder else null
                                ) {
                                    Text(
                                        text = "$months ماه",
                                        color = if (isSelected) Color.White else TextPrimaryDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Calculation Summary Card
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SoftBlueContainer.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("پیش‌پرداخت نقدی:", fontSize = 12.sp, color = TextSecondaryMuted)
                                    Text(formatTomans(calculationResult.downPayment), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("مبلغ هر قسط ماهانه:", fontSize = 12.sp, color = TextSecondaryMuted)
                                    Text(
                                        formatTomans(calculationResult.monthlyPayment),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = SoftBluePrimary
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("نرخ کارمزد سالانه:", fontSize = 12.sp, color = TextSecondaryMuted)
                                    Text("${calculationResult.interestPercent} درصد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Divider(color = SoftBlueLight.copy(alpha = 0.5f))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("مجموع پرداختی با اقساط:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        formatTomans(calculationResult.totalWithInterest),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MedicalGreenDark
                                    )
                                }
                            }
                        }
                    }

                    // Cheques Breakdown Title
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.FactCheck,
                                contentDescription = null,
                                tint = MedicalGreenPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "جدول چک‌های صیادی (${calculationResult.cheques.size} فقره چک):",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                        }
                    }

                    // Cheque items
                    items(calculationResult.cheques) { cheque ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(10.dp),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(26.dp)
                                            .clip(CircleShape)
                                            .background(MedicalGreenContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${cheque.chequeNumber}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = OnMedicalGreenContainer
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "سررسید: ${cheque.dueDate}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimaryDark
                                        )
                                        Text(
                                            text = "شناسه نمونه: ${cheque.sayadId}",
                                            fontSize = 9.sp,
                                            color = TextTertiary
                                        )
                                    }
                                }

                                Text(
                                    text = formatTomans(cheque.amountTomans),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MedicalGreenDark
                                )
                            }
                        }
                    }

                    // Sayad Central Bank Note
                    item {
                        Surface(
                            color = AmberDiscountContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = AmberDiscount,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "کلیه چک‌ها باید بنفش صیادی و دارای ثبت تاییدیه در سامانه پیچک بانک مرکزی باشند.",
                                    fontSize = 10.sp,
                                    color = TextSecondaryMuted,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Button: Proceed to Installment Checkout
                Button(
                    onClick = onProceedToInstallmentCheckout,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("proceed_installment_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SoftBluePrimary)
                ) {
                    Icon(imageVector = Icons.Default.ShoppingCartCheckout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ثبت نهایی و تسویه اقساطی با چک صیادی",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
