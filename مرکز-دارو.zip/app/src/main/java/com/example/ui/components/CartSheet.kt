package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.CartItem
import com.example.ui.theme.*

@Composable
fun CartSheet(
    cartItems: List<CartItem>,
    appliedCouponCode: String?,
    discountPercent: Int,
    onUpdateQuantity: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onApplyCoupon: (String) -> Boolean,
    onRemoveCoupon: () -> Unit,
    onDismiss: () -> Unit,
    onProceedToCheckout: (isInstallment: Boolean) -> Unit
) {
    var couponInput by remember { mutableStateOf("") }
    var couponError by remember { mutableStateOf<String?>(null) }

    val rawTotal = cartItems.sumOf { it.product.price * it.quantity }
    val discountAmount = if (discountPercent > 0) (rawTotal * discountPercent) / 100 else 0L
    val payableAmount = (rawTotal - discountAmount).coerceAtLeast(0)

    val anyInstallmentEligible = cartItems.any { it.product.isInstallmentEligible }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .testTag("cart_sheet_dialog"),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            tint = MedicalGreenDark
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "سبد خرید شما (${cartItems.sumOf { it.quantity }} قلم)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "بستن")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (cartItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.RemoveShoppingCart,
                                contentDescription = null,
                                tint = TextTertiary,
                                modifier = Modifier.size(60.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("سبد خرید شما در حال حاضر خالی است", fontSize = 13.sp, color = TextSecondaryMuted)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("محصولات دارویی و بهداشتی مورد نظر خود را اضافه نمایید", fontSize = 11.sp, color = TextTertiary)
                        }
                    }
                } else {
                    // Cart Items List
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(cartItems) { item ->
                            Surface(
                                color = MedicalSurfaceVariant,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.product.title,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            color = TextPrimaryDark
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${item.product.brand} - ${item.product.dosageForm}",
                                            fontSize = 10.sp,
                                            color = TextTertiary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = formatTomans(item.product.price * item.quantity),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MedicalGreenDark
                                        )
                                    }

                                    // Quantity Controls
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.background(Color.White, shape = RoundedCornerShape(8.dp))
                                    ) {
                                        IconButton(
                                            onClick = { onUpdateQuantity(item.product.id, -1) },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (item.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
                                                contentDescription = "کاهش",
                                                tint = if (item.quantity == 1) RoseDiscount else TextPrimaryDark,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        Text(
                                            text = "${item.quantity}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        )

                                        IconButton(
                                            onClick = { onUpdateQuantity(item.product.id, 1) },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "افزایش",
                                                tint = MedicalGreenPrimary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Coupon Input Box
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(12.dp),
                                border = ButtonDefaults.outlinedButtonBorder,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    if (appliedCouponCode != null) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "کد $appliedCouponCode اعمال شد ($discountPercent٪ تخفیف)",
                                                    color = SuccessGreen,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            }
                                            TextButton(onClick = onRemoveCoupon) {
                                                Text("حذف", color = RoseDiscount, fontSize = 11.sp)
                                            }
                                        }
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = couponInput,
                                                onValueChange = {
                                                    couponInput = it
                                                    couponError = null
                                                },
                                                placeholder = { Text("کد تخفیف (مثال: SALAMAT15)", fontSize = 11.sp) },
                                                modifier = Modifier.weight(1f),
                                                singleLine = true,
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    val success = onApplyCoupon(couponInput)
                                                    if (!success) {
                                                        couponError = "کد واردشده نامعتبر یا منقضی است"
                                                    } else {
                                                        couponInput = ""
                                                    }
                                                },
                                                shape = RoundedCornerShape(10.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = SoftBluePrimary)
                                            ) {
                                                Text("ثبت کد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        if (couponError != null) {
                                            Text(
                                                text = couponError!!,
                                                color = RoseDiscount,
                                                fontSize = 10.sp,
                                                modifier = Modifier.padding(top = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Order Summary Calculations
                        item {
                            Surface(
                                color = SoftBlueContainer.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("جمع مبالغ اقلام:", fontSize = 11.sp, color = TextSecondaryMuted)
                                        Text(formatTomans(rawTotal), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    if (discountAmount > 0) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("سود شما از خرید (تخفیف):", fontSize = 11.sp, color = RoseDiscount)
                                            Text(
                                                text = "${formatTomans(discountAmount)}-",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = RoseDiscount
                                            )
                                        }
                                    }

                                    Divider(color = SoftBlueLight)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("مبلغ نهایی قابل پرداخت:", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                                        Text(
                                            text = formatTomans(payableAmount),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MedicalGreenDark
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Checkout Buttons: Cash & Installment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Regular Cash Online Payment
                        Button(
                            onClick = {
                                onProceedToCheckout(false)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("checkout_cash_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                        ) {
                            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("پرداخت آنلاین نقدی", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Installment Checkout if eligible
                        if (anyInstallmentEligible) {
                            Button(
                                onClick = {
                                    onProceedToCheckout(true)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("checkout_installment_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SoftBluePrimary)
                            ) {
                                Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("خرید اقساط صیادی", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
