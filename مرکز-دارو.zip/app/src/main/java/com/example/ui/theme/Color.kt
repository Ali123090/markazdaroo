package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Medical Green
val MedicalGreenPrimary = Color(0xFF00897B)
val MedicalGreenDark = Color(0xFF005B4F)
val MedicalGreenLight = Color(0xFF4EBaaa)
val MedicalGreenContainer = Color(0xFFE0F2F1)
val OnMedicalGreenContainer = Color(0xFF003830)

// Gentle Soft Blue
val SoftBluePrimary = Color(0xFF0284C7)
val SoftBlueLight = Color(0xFFBAE6FD)
val SoftBlueContainer = Color(0xFFE0F2FE)
val OnSoftBlueContainer = Color(0xFF075985)
val SoftBlueMuted = Color(0xFFE2E8F0)

// Accent & Status Colors
val AmberDiscount = Color(0xFFD97706)
val AmberDiscountContainer = Color(0xFFFEF3C7)
val RoseDiscount = Color(0xFFE11D48)
val RoseContainer = Color(0xFFFFE4E6)
val SuccessGreen = Color(0xFF10B981)

// Background & Surfaces
val MedicalSurfaceLight = Color(0xFFF8FAFC)
val MedicalSurfaceVariant = Color(0xFFF1F5F9)
val MedicalCardSurface = Color(0xFFFFFFFF)
val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryMuted = Color(0xFF475569)
val TextTertiary = Color(0xFF94A3B8)
val OutlineBorder = Color(0xFFCBD5E1)

// Dark Palette
val DarkBackground = Color(0xFF0B131E)
val DarkSurface = Color(0xFF131F2E)
val DarkCardSurface = Color(0xFF1A2B3C)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)
