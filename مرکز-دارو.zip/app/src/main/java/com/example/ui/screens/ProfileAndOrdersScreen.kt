package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.AppNotification
import com.example.data.models.Order
import com.example.data.models.OrderStatus
import com.example.ui.components.formatTomans
import com.example.ui.theme.*

@Composable
fun ProfileAndOrdersScreen(
    orders: List<Order>,
    notifications: List<AppNotification>,
    onTrackOrder: (Order) -> Unit
) {
    var searchTrackingCode by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_and_orders_screen")
    ) {
        // Profile Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MedicalSurfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(MedicalGreenPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "دکتر آرش رضایی",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = AmberDiscountContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "باشگاه طلایی سلامت",
                                    color = AmberDiscount,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "۰۹۱۲۳۴۵۶۷۸۹ - تهران، ولیعصر",
                            fontSize = 11.sp,
                            color = TextSecondaryMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats Row: Total orders, active sayad cheques, health score
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ProfileStatItem(title = "کل سفارشات", value = "${orders.size} خرید")
                    ProfileStatItem(title = "چک صیادی فعال", value = "${orders.filter { it.isInstallment }.sumOf { it.sayadChequeCount }} فقره")
                    ProfileStatItem(title = "اعتبار سلامت", value = "۲۵۰,۰۰۰ ت")
                }
            }
        }

        // Sub Tabs: "تاریخچه و پیگیری سفارشات" vs "اعلان‌های شخصی"
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MedicalGreenPrimary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("تاریخچه و پیگیری سفارشات (${orders.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("اعلان‌ها و یادآورها (${notifications.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        if (selectedTab == 0) {
            // Orders & Tracking Tab
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Tracking Code Quick Search Field
                item {
                    OutlinedTextField(
                        value = searchTrackingCode,
                        onValueChange = { searchTrackingCode = it },
                        placeholder = { Text("جستجوی کد رهگیری (مثلاً: IR-DAROO-948210)...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MedicalGreenPrimary)
                        }
                    )
                }

                val displayedOrders = if (searchTrackingCode.isNotBlank()) {
                    orders.filter { it.trackingCode.contains(searchTrackingCode.trim(), ignoreCase = true) }
                } else orders

                items(displayedOrders) { order ->
                    OrderTrackingCard(order = order, onTrackClick = { onTrackOrder(order) })
                }
            }
        } else {
            // Notifications Tab
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notifications) { notif ->
                    Surface(
                        color = if (notif.isRead) MaterialTheme.colorScheme.surface else MedicalGreenContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(12.dp),
                        border = ButtonDefaults.outlinedButtonBorder,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(SoftBlueContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = SoftBluePrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(notif.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                                    Text(notif.timeAgo, fontSize = 9.sp, color = TextTertiary)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(notif.body, fontSize = 11.sp, color = TextSecondaryMuted, lineHeight = 15.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrderTrackingCard(
    order: Order,
    onTrackClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Tracking code and Status badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = order.trackingCode,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SoftBluePrimary
                )
                Surface(
                    color = when (order.status) {
                        OrderStatus.REGISTERED -> AmberDiscountContainer
                        OrderStatus.PHARMACIST_APPROVED -> SoftBlueContainer
                        OrderStatus.PROCESSING_PACKAGING -> MedicalGreenContainer
                        OrderStatus.DISPATCHED -> MedicalGreenContainer
                        OrderStatus.DELIVERED -> SuccessGreen.copy(alpha = 0.2f)
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = order.status.titleFa,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (order.status) {
                            OrderStatus.REGISTERED -> AmberDiscount
                            OrderStatus.PHARMACIST_APPROVED -> SoftBluePrimary
                            OrderStatus.PROCESSING_PACKAGING -> MedicalGreenDark
                            OrderStatus.DISPATCHED -> MedicalGreenDark
                            OrderStatus.DELIVERED -> SuccessGreen
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Items breakdown
            order.items.forEach { item ->
                Text(
                    text = "• ${item.product.title} (تعداد: ${item.quantity})",
                    fontSize = 11.sp,
                    color = TextSecondaryMuted,
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5-Stage Live Order Timeline
            OrderTimelineIndicator(currentStatus = order.status)

            Spacer(modifier = Modifier.height(10.dp))

            // Price & Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("مبلغ پرداختی:", fontSize = 10.sp, color = TextTertiary)
                    Text(
                        text = formatTomans(order.payableAmount),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MedicalGreenDark
                    )
                }

                if (order.isInstallment) {
                    Surface(
                        color = SoftBlueContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "اقساطی (${order.sayadChequeCount} فقره چک صیادی)",
                            fontSize = 10.sp,
                            color = OnSoftBlueContainer,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Button(
                    onClick = onTrackClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("جزئیات پیگیری", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun OrderTimelineIndicator(currentStatus: OrderStatus) {
    val steps = listOf(
        OrderStatus.REGISTERED,
        OrderStatus.PHARMACIST_APPROVED,
        OrderStatus.PROCESSING_PACKAGING,
        OrderStatus.DISPATCHED,
        OrderStatus.DELIVERED
    )

    val currentIndex = steps.indexOf(currentStatus).coerceAtLeast(0)

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, step ->
            val isCompleted = index <= currentIndex
            val isCurrent = index == currentIndex

            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCurrent) MedicalGreenPrimary
                        else if (isCompleted) SuccessGreen
                        else OutlineBorder
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }

            if (index < steps.size - 1) {
                Divider(
                    modifier = Modifier.weight(1f),
                    color = if (index < currentIndex) SuccessGreen else OutlineBorder,
                    thickness = 2.dp
                )
            }
        }
    }
}

@Composable
fun ProfileStatItem(title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, fontSize = 10.sp, color = TextSecondaryMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MedicalGreenDark)
    }
}
