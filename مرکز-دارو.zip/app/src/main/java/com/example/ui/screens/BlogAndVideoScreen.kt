package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.HealthArticle
import com.example.data.models.Product
import com.example.ui.components.formatTomans
import com.example.ui.theme.*

@Composable
fun BlogAndVideoScreen(
    articles: List<HealthArticle>,
    allProducts: List<Product>,
    onAddToCart: (Product) -> Unit,
    onOpenProduct: (Product) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    var activePlayingVideoId by remember { mutableStateOf<String?>(null) }

    val filteredArticles = when (selectedTab) {
        1 -> articles.filter { it.hasVideo }
        2 -> articles.filter { !it.hasVideo }
        else -> articles
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("blog_and_video_screen")
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MedicalGreenPrimary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("همه مطالب سلامت", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("ویدیوهای آموزشی", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("مقالات تخصصی", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(filteredArticles) { article ->
                val isPlaying = activePlayingVideoId == article.id

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Video or Media Hero Box
                        if (article.hasVideo) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                                        )
                                    )
                                    .clickable {
                                        activePlayingVideoId = if (isPlaying) null else article.id
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isPlaying) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PauseCircleFilled,
                                            contentDescription = "توقف ویدیو",
                                            tint = SuccessGreen,
                                            modifier = Modifier.size(54.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "در حال پخش ویدیو تخصصی داروساز...",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        LinearProgressIndicator(
                                            progress = { 0.45f },
                                            modifier = Modifier
                                                .fillMaxWidth(0.8f)
                                                .height(4.dp),
                                            color = SuccessGreen,
                                            trackColor = Color.White.copy(alpha = 0.3f)
                                        )
                                    }
                                } else {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.PlayCircleFilled,
                                            contentDescription = "پخش ویدیو",
                                            tint = Color.White,
                                            modifier = Modifier.size(56.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "برای پخش ویدیو کلیک کنید",
                                            color = Color.White.copy(alpha = 0.8f),
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                // Duration pill
                                if (article.videoDuration != null) {
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.7f),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(10.dp)
                                    ) {
                                        Text(
                                            text = article.videoDuration,
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Article Body
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MedicalGreenPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = article.author,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MedicalGreenDark
                                    )
                                }
                                Text(
                                    text = article.datePersian,
                                    fontSize = 10.sp,
                                    color = TextTertiary
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = article.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimaryDark,
                                lineHeight = 20.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = article.summary,
                                fontSize = 11.sp,
                                color = TextSecondaryMuted,
                                lineHeight = 16.sp
                            )

                            // Key Takeaways
                            if (article.keyTakeaways.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    color = SoftBlueContainer.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "نکات کلیدی پزشکی:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = OnSoftBlueContainer
                                        )
                                        article.keyTakeaways.forEach { takeaway ->
                                            Text(
                                                text = "• $takeaway",
                                                fontSize = 10.sp,
                                                color = TextPrimaryDark,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }
                                }
                            }

                            // Related Products section in Article
                            if (article.relatedProductIds.isNotEmpty()) {
                                val relProds = allProducts.filter { it.id in article.relatedProductIds }
                                if (relProds.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "داروها و مکمل‌های معرفی‌شده در این مطلب:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        relProds.forEach { prod ->
                                            Surface(
                                                color = MedicalSurfaceVariant,
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(8.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clickable { onOpenProduct(prod) }
                                                    ) {
                                                        Text(
                                                            text = prod.title,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            maxLines = 1
                                                        )
                                                        Text(
                                                            text = formatTomans(prod.price),
                                                            fontSize = 10.sp,
                                                            color = MedicalGreenDark,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                    Button(
                                                        onClick = { onAddToCart(prod) },
                                                        shape = RoundedCornerShape(6.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                        modifier = Modifier.height(30.dp)
                                                    ) {
                                                        Text("خرید مستقیم", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
