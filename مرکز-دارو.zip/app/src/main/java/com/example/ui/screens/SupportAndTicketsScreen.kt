package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportAndTicketsScreen(
    tickets: List<SupportTicket>,
    chatMessages: List<LiveChatMessage>,
    onSendChatMessage: (String) -> Unit,
    onCreateTicket: (subject: String, dept: TicketDepartment, priority: TicketPriority, message: String) -> Unit,
    onReplyTicket: (ticketId: String, text: String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    var showNewTicketDialog by remember { mutableStateOf(false) }
    var chatInput by remember { mutableStateOf("") }
    var expandedTicketId by remember { mutableStateOf<String?>(null) }
    var ticketReplyInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("support_and_tickets_screen")
    ) {
        // Tab Row: Live Chat vs Tickets
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MedicalGreenPrimary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("چت آنلاین داروساز", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ثبت و پیگیری تیکت (${tickets.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        if (selectedTab == 0) {
            // Live Chat View
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                // Online Pharmacist status indicator
                Surface(
                    color = MedicalGreenContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(SuccessGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "داروساز آنلاین مرکز دارو آماده پاسخگویی به سوالات مصرف و تداخلات است.",
                            fontSize = 11.sp,
                            color = MedicalGreenDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { msg ->
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
                        ) {
                            Surface(
                                color = if (msg.isUser) MedicalGreenPrimary else SoftBlueContainer.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.widthIn(max = 290.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = msg.senderName,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (msg.isUser) Color.White.copy(alpha = 0.8f) else SoftBluePrimary
                                        )
                                        Text(
                                            text = msg.timePersian,
                                            fontSize = 9.sp,
                                            color = if (msg.isUser) Color.White.copy(alpha = 0.7f) else TextTertiary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.text,
                                        fontSize = 12.sp,
                                        color = if (msg.isUser) Color.White else TextPrimaryDark,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Chat Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 70.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = chatInput,
                        onValueChange = { chatInput = it },
                        placeholder = { Text("پیام خود را بنویسید...", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (chatInput.isNotBlank()) {
                                onSendChatMessage(chatInput)
                                chatInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(MedicalGreenPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "ارسال", tint = Color.White)
                    }
                }
            }
        } else {
            // Tickets List View
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // New Ticket Button
                Button(
                    onClick = { showNewTicketDialog = true },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SoftBluePrimary)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ارسال تیکت پشتیبانی جدید", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 70.dp)
                ) {
                    items(tickets) { ticket ->
                        val isExpanded = expandedTicketId == ticket.id

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = ticket.trackingCode,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SoftBluePrimary
                                    )
                                    Surface(
                                        color = when (ticket.status) {
                                            TicketStatus.OPEN -> AmberDiscountContainer
                                            TicketStatus.ANSWERED -> MedicalGreenContainer
                                            TicketStatus.CLOSED -> RoseContainer
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = ticket.status.titleFa,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (ticket.status) {
                                                TicketStatus.OPEN -> AmberDiscount
                                                TicketStatus.ANSWERED -> MedicalGreenDark
                                                TicketStatus.CLOSED -> RoseDiscount
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = ticket.subject,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextPrimaryDark
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "دپارتمان: ${ticket.department.titleFa}",
                                        fontSize = 10.sp,
                                        color = TextTertiary
                                    )
                                    Text(
                                        text = ticket.createdDate,
                                        fontSize = 10.sp,
                                        color = TextTertiary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                TextButton(
                                    onClick = {
                                        expandedTicketId = if (isExpanded) null else ticket.id
                                    }
                                ) {
                                    Text(
                                        text = if (isExpanded) "بستن تاریخچه گفتگو ▲" else "مشاهده پیام‌ها و پاسخ (${ticket.messages.size}) ▼",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (isExpanded) {
                                    Divider(color = OutlineBorder.copy(alpha = 0.4f))
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        ticket.messages.forEach { msg ->
                                            Surface(
                                                color = if (msg.isSupport) SoftBlueContainer.copy(alpha = 0.4f) else MedicalSurfaceVariant,
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text(msg.sender, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                        Text(msg.timePersian, fontSize = 9.sp, color = TextTertiary)
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(msg.message, fontSize = 11.sp, color = TextPrimaryDark, lineHeight = 15.sp)
                                                }
                                            }
                                        }

                                        // Reply Input
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = ticketReplyInput,
                                                onValueChange = { ticketReplyInput = it },
                                                placeholder = { Text("پاسخ به تیکت...", fontSize = 10.sp) },
                                                modifier = Modifier.weight(1f),
                                                singleLine = true,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Button(
                                                onClick = {
                                                    if (ticketReplyInput.isNotBlank()) {
                                                        onReplyTicket(ticket.id, ticketReplyInput)
                                                        ticketReplyInput = ""
                                                    }
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                                            ) {
                                                Text("ارسال", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Ticket Dialog
    if (showNewTicketDialog) {
        var subject by remember { mutableStateOf("") }
        var selectedDept by remember { mutableStateOf<TicketDepartment>(TicketDepartment.PHARMACIST_CONSULT) }
        var selectedPriority by remember { mutableStateOf(TicketPriority.MEDIUM) }
        var messageText by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showNewTicketDialog = false }) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ثبت تیکت پشتیبانی جدید", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimaryDark)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("موضوع تیکت", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("دپارتمان مربوطه:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    TicketDepartment.values().forEach { dept ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedDept = dept }
                        ) {
                            RadioButton(selected = selectedDept == dept, onClick = { selectedDept = dept })
                            Text(dept.titleFa, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        label = { Text("متن درخواست یا شرح مسئله", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (subject.isNotBlank() && messageText.isNotBlank()) {
                                onCreateTicket(subject, selectedDept, selectedPriority, messageText)
                                showNewTicketDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MedicalGreenPrimary)
                    ) {
                        Text("ارسال و ثبت نهایی تیکت")
                    }
                }
            }
        }
    }
}
