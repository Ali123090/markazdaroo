package com.example.data.models

enum class ProductCategory(val persianTitle: String, val iconName: String) {
    ALL("همه محصولات", "grid"),
    MEDICINE("داروهای عمومی و OTC", "pill"),
    SUPPLEMENTS("مکمل‌های ورزشی و تقویتی", "fitness"),
    MEDICAL_EQUIPMENT("تجهیزات و ابزار پزشکی", "device"),
    DERMO_COSMETIC("پوست، مو و بهداشتی", "spa"),
    MOTHER_AND_BABY("مادر و کودک", "child")
}

data class Product(
    val id: String,
    val title: String,
    val genericName: String,
    val category: ProductCategory,
    val price: Long, // in Tomans
    val originalPrice: Long,
    val discountPercent: Int = 0,
    val rating: Float = 4.8f,
    val reviewCount: Int = 24,
    val inStock: Boolean = true,
    val dosageForm: String, // قرص، کپسول، ساشه، دستگاه، کرم
    val brand: String,
    val country: String,
    val activeIngredients: String, // ترکیبات فعال
    val description: String,
    val usageInstruction: String,
    val warnings: String,
    val isPrescriptionRequired: Boolean = false,
    val isInstallmentEligible: Boolean = true,
    val primaryColorHex: Long = 0xFF00897B,
    val badge: String? = null, // پرفروش, پیشنهاد داروساز, تخفیف ویژه
    val reviews: List<ProductReview> = emptyList()
)

data class CartItem(
    val product: Product,
    val quantity: Int
)

data class SayadChequeItem(
    val chequeNumber: Int,
    val dueDate: String,
    val amountTomans: Long,
    val sayadId: String = ""
)

data class SayadCalculationResult(
    val totalAmount: Long,
    val downPayment: Long,
    val remainingAmount: Long,
    val months: Int,
    val interestPercent: Float,
    val monthlyPayment: Long,
    val totalWithInterest: Long,
    val cheques: List<SayadChequeItem>
)

enum class OrderStatus(val titleFa: String, val stepIndex: Int) {
    REGISTERED("ثبت سفارش و پرداخت موفق", 1),
    PHARMACIST_APPROVED("تأیید نسخه و نظارت دکتر داروساز", 2),
    PROCESSING_PACKAGING("بسته‌بندی بهداشتی در انبار", 3),
    DISPATCHED("تحویل به پست پیشتاز / پیک اکسپرس", 4),
    DELIVERED("تحویل نهایی به مشتری", 5)
}

data class Order(
    val id: String,
    val trackingCode: String,
    val items: List<CartItem>,
    val totalAmount: Long,
    val discountAmount: Long,
    val payableAmount: Long,
    val datePersian: String,
    val status: OrderStatus,
    val paymentGateway: String,
    val isInstallment: Boolean = false,
    val sayadChequeCount: Int = 0,
    val shippingAddress: String,
    val recipientName: String,
    val recipientPhone: String
)

enum class TicketDepartment(val titleFa: String) {
    PHARMACIST_CONSULT("مشاوره تخصصی داروساز", ),
    ORDER_TRACKING("پیگیری ارسال و سفارشات"),
    INSTALLMENT_SAYAD("امور مالی و چک‌های صیادی"),
    TECHNICAL_SUPPORT("پشتیبانی فنی و انتقادات")
}

enum class TicketPriority(val titleFa: String) {
    NORMAL("عادی"),
    MEDIUM("متوسط"),
    URGENT("فوری")
}

enum class TicketStatus(val titleFa: String) {
    OPEN("در انتظار بررسی"),
    ANSWERED("پاسخ داده شده"),
    CLOSED("بسته شده")
}

data class TicketMessage(
    val id: String,
    val sender: String,
    val isSupport: Boolean,
    val message: String,
    val timePersian: String
)

data class SupportTicket(
    val id: String,
    val trackingCode: String,
    val subject: String,
    val department: TicketDepartment,
    val priority: TicketPriority,
    val status: TicketStatus,
    val createdDate: String,
    val messages: List<TicketMessage>
)

data class LiveChatMessage(
    val id: String,
    val senderName: String,
    val isUser: Boolean,
    val isAiPharmacist: Boolean,
    val text: String,
    val timePersian: String,
    val suggestedProductIds: List<String> = emptyList()
)

data class ProductReview(
    val id: String,
    val author: String,
    val rating: Int,
    val datePersian: String,
    val comment: String,
    val isVerifiedBuyer: Boolean,
    val pros: List<String> = emptyList(),
    val cons: List<String> = emptyList()
)

data class HealthArticle(
    val id: String,
    val title: String,
    val category: String,
    val author: String,
    val datePersian: String,
    val readingTime: String,
    val summary: String,
    val content: String,
    val hasVideo: Boolean = false,
    val videoTitle: String? = null,
    val videoDuration: String? = null,
    val keyTakeaways: List<String> = emptyList(),
    val relatedProductIds: List<String> = emptyList()
)

enum class NotificationType {
    DISCOUNT,
    ORDER_STATUS,
    HEALTH_REMINDER
}

data class AppNotification(
    val id: String,
    val title: String,
    val body: String,
    val timeAgo: String,
    val type: NotificationType,
    val couponCode: String? = null,
    val isRead: Boolean = false
)
