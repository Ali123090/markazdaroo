package com.example.data

import com.example.data.models.*

object PharmacyData {

    val initialProducts: List<Product> = listOf(
        Product(
            id = "p-101",
            title = "سافت‌ژل ویتامین D3 ۵۰۰۰۰ واحد دانا",
            genericName = "Cholecalciferol (Vitamin D3) 50,000 IU",
            category = ProductCategory.MEDICINE,
            price = 95000,
            originalPrice = 120000,
            discountPercent = 21,
            rating = 4.9f,
            reviewCount = 84,
            inStock = true,
            dosageForm = "سافت‌ژل (کپسول نرم)",
            brand = "داروسازی دانا",
            country = "ایران",
            activeIngredients = "کوله کلسیفرول ۵۰۰۰۰ واحد بین‌المللی",
            description = "کمک به تقویت سیستم ایمنی، حفظ سلامت و استحکام استخوان‌ها و دندان‌ها و پیشگیری از پوکی استخوان.",
            usageInstruction = "ماهیانه یک عدد همراه با وعده غذایی چرب میل شود یا طبق دستور پزشک معالج مصرف گردد.",
            warnings = "در صورت سابقه سنگ کلیه کلسیمی یا هیپرکلسمی با پزشک مشورت شود.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFF00897B,
            badge = "پرفروش‌ترین"
        ),
        Product(
            id = "p-102",
            title = "دستگاه فشارسنج دیجیتال بازویی بیورر مدل BM55",
            genericName = "Beurer BM55 Upper Arm Blood Pressure Monitor",
            category = ProductCategory.MEDICAL_EQUIPMENT,
            price = 4850000,
            originalPrice = 5700000,
            discountPercent = 15,
            rating = 4.9f,
            reviewCount = 52,
            inStock = true,
            dosageForm = "دستگاه دیجیتال بازویی",
            brand = "بیورر (Beurer)",
            country = "آلمان",
            activeIngredients = "حسگر پیشرفته اسیلومتریک، کاف ۲۲ تا ۴۲ سانتی‌متر",
            description = "فشارسنج حرفه‌ای با نمایشگر بزرگ لمسی، قابلیت اتصال به کامپیوتر، تشخیص آریتمی قلبی و حافظه ذخیره برای ۲ کاربر.",
            usageInstruction = "قبل از اندازه‌گیری ۵ دقیقه استراحت نموده و کاف را ۲ سانتی‌متر بالاتر از خم آرنج ببندید.",
            warnings = "هنگام اندازه‌گیری از صحبت کردن و حرکت دست خودداری فرمایید.",
            isPrescriptionRequired = false,
            isInstallmentEligible = true,
            primaryColorHex = 0xFF0284C7,
            badge = "خرید اقساطی صیادی"
        ),
        Product(
            id = "p-103",
            title = "پودر پروتئین وی ایزوله ۱۰۰٪ دوبیس ۲۲۷۰ گرم",
            genericName = "100% Pure Whey Isolate Protein Powder 2.27kg",
            category = ProductCategory.SUPPLEMENTS,
            price = 3200000,
            originalPrice = 3650000,
            discountPercent = 12,
            rating = 4.7f,
            reviewCount = 41,
            inStock = true,
            dosageForm = "پودر طعم‌دار شکلاتی",
            brand = "دوبیس (Doobis)",
            country = "ایران (مواد اولیه اروپا)",
            activeIngredients = "پروتئین وی ایزوله با جذب بالا، BCAA و گلوتامین",
            description = "حاوی ۲۵ گرم پروتئین خالص در هر سروینگ با حداقل چربی و کربوهیدرات جهت افزایش حجم خشک عضلانی و ریکاوری سریع.",
            usageInstruction = "یک اسکوپ ۳۰ گرمی را در ۲۵۰ میلی‌لیتر آب یا شیر کم‌چرب بلافاصله بعد از تمرین مخلوط و مصرف نمایید.",
            warnings = "افراد دارای نارسایی کلیوی یا آلرژی شدید به شیر قبل از مصرف با پزشک مشورت کنند.",
            isPrescriptionRequired = false,
            isInstallmentEligible = true,
            primaryColorHex = 0xFF059669,
            badge = "تخفیف ویژه"
        ),
        Product(
            id = "p-104",
            title = "سرم ویتامین C روشن‌کننده و ضدلک لافارر",
            genericName = "Lafarrerr Vitamin C 20% + E Facial Serum",
            category = ProductCategory.DERMO_COSMETIC,
            price = 780000,
            originalPrice = 980000,
            discountPercent = 20,
            rating = 4.8f,
            reviewCount = 63,
            inStock = true,
            dosageForm = "سرم ۳۰ میلی‌لیتر قطره‌چکانی",
            brand = "لافارر (Lafarrerr)",
            country = "ایران (فرمولاسیون فرانسه)",
            activeIngredients = "ویتامین C پایدار ۲۰٪، ویتامین E، اسید فرولیک",
            description = "تحریک سنتز کلاژن، کاهش چین و چروک ریز، برطرف‌کننده لک‌های ناشی از آفتاب و پیری پوست و درخشان‌کننده چهره.",
            usageInstruction = "شب‌ها ۳ الی ۵ قطره روی پوست تمیز صورت ماساژ دهید و در طول روز حتماً از ضدآفتاب استفاده نمایید.",
            warnings = "از تماس با چشم و لب‌ها خودداری شود. در جای خنک و دور از تابش مستقیم آفتاب نگهداری شود.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFFD97706,
            badge = "پیشنهاد داروساز"
        ),
        Product(
            id = "p-105",
            title = "دستگاه تست قند خون اکیوچک مدل اینستنت همراه با ۵۰ نوار",
            genericName = "Accu-Chek Instant Blood Glucose Monitoring Kit",
            category = ProductCategory.MEDICAL_EQUIPMENT,
            price = 1450000,
            originalPrice = 1680000,
            discountPercent = 14,
            rating = 4.9f,
            reviewCount = 98,
            inStock = true,
            dosageForm = "کیت تست قند خون (دستگاه + لانست + ۵۰ نوار)",
            brand = "اکیوچک (Accu-Chek)",
            country = "آلمان",
            activeIngredients = "سنجش آنزیمی گلوکز، دقت ۹۹.۴ درصدی",
            description = "اندازه‌گیری فوق‌العاده سریع قند خون در کمتر از ۴ ثانیه بدون نیاز به کدگذاری، با چراغ راهنمای محدوده هدف.",
            usageInstruction = "یک قطره خون کوچک (۰.۶ میکرولیتر) روی لبه نوار تست قرار داده و نتیجه را روی صفحه مشاهده کنید.",
            warnings = "نوارهای تست را فقط در قوطی دربسته در دمای ۴ تا ۳۰ درجه سانتی‌گراد نگهداری نمایید.",
            isPrescriptionRequired = false,
            isInstallmentEligible = true,
            primaryColorHex = 0xFF0284C7,
            badge = "گارانتی مادام‌العمر"
        ),
        Product(
            id = "p-106",
            title = "شربت ایمیونس ویتابیوتیکس ۲۰۰ میلی‌لیتر",
            genericName = "Vitabiotics Immunace Liquid 200ml",
            category = ProductCategory.MEDICINE,
            price = 340000,
            originalPrice = 410000,
            discountPercent = 17,
            rating = 4.8f,
            reviewCount = 76,
            inStock = true,
            dosageForm = "شربت خوراکی با طعم پرتقالی",
            brand = "ویتابیوتیکس (Vitabiotics)",
            country = "انگلستان (تحت لیسانس)",
            activeIngredients = "زینک، ویتامین D3، اکیناسه، سلنیوم، ب کمپلکس",
            description = "مکمل تخصصی تقویت سیستم ایمنی کودکان و بزرگسالان، پیشگیری و کوتاه کردن دوره سرماخوردگی و آنفلوآنزا.",
            usageInstruction = "کودکان بالای ۴ سال روزانه یک قاشق مرباخوری (۵ میلی‌لیتر) و بزرگسالان دو قاشق مرباخوری میل کنند.",
            warnings = "در دوران بارداری و شیردهی طبق تجویز پزشک مصرف شود.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFF00897B,
            badge = "ویژه فصول سرد"
        ),
        Product(
            id = "p-107",
            title = "قرص کلاژن گلد آدریان پلاس هیالورونیک اسید و ویتامین C",
            genericName = "Collagen Gold Hyaluronic Acid & Vitamin C",
            category = ProductCategory.SUPPLEMENTS,
            price = 620000,
            originalPrice = 750000,
            discountPercent = 17,
            rating = 4.7f,
            reviewCount = 37,
            inStock = true,
            dosageForm = "قرص روکش‌دار (بسته ۶۰ عددی)",
            brand = "آدریان سلامت",
            country = "ایران",
            activeIngredients = "کلاژن هیدرولیز شده نوع ۱ و ۳، هیالورونیک اسید، ویتامین C",
            description = "جوانسازی، آبرسانی عمقی لایه‌های پوست، سفت‌کننده بافت صورت و پیشگیری از افتادگی پوست و تقویت مفاصل.",
            usageInstruction = "روزانه ۱ الی ۲ عدد قرص شب‌ها قبل از خواب همراه با آب فراوان میل شود.",
            warnings = "برای افراد زیر ۱۸ سال توصیه نمی‌شود.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFFD97706,
            badge = "جوانسازی پوست"
        ),
        Product(
            id = "p-108",
            title = "کرم ترمیم‌کننده پوست سیکالفیت پلاس اون ۱۰۰ میلی‌لیتر",
            genericName = "Avene Cicalfate+ Restorative Protective Cream 100ml",
            category = ProductCategory.DERMO_COSMETIC,
            price = 1890000,
            originalPrice = 2200000,
            discountPercent = 14,
            rating = 5.0f,
            reviewCount = 112,
            inStock = true,
            dosageForm = "کرم ترمیم‌کننده موضعی",
            brand = "اون (Avene)",
            country = "فرانسه",
            activeIngredients = "میکروبیوما، سولفات مس و روی، آب چشمه حرارتی اون",
            description = "ترمیم سریع زخم، سوختگی سطحی، جای جوش، التهابات پس از لیزر و بخیه با خواص آنتی‌باکتریال و التیام‌بخش فوق‌العاده.",
            usageInstruction = "روزانه ۲ مرتبه روی پوست تمیز و خشک در ناحیه آسیب‌دیده ماساژ ملایم دهید.",
            warnings = "روی زخم باز و ترشح‌دار استفاده نشود.",
            isPrescriptionRequired = false,
            isInstallmentEligible = true,
            primaryColorHex = 0xFF0284C7,
            badge = "اصل با لیبل اصالت"
        ),
        Product(
            id = "p-109",
            title = "قطره مولتی‌ویتامین و آهن پدیابست ۳۰ میلی‌لیتر",
            genericName = "Pedia Best Multivitamin Drops for Infants 30ml",
            category = ProductCategory.MOTHER_AND_BABY,
            price = 185000,
            originalPrice = 225000,
            discountPercent = 18,
            rating = 4.8f,
            reviewCount = 45,
            inStock = true,
            dosageForm = "قطره خوراکی همراه با قطره‌چکان مدرج",
            brand = "پدیابست (Pedia Best)",
            country = "پرتغال (تحت لیسانس)",
            activeIngredients = "آهن لیپوزومال بدون سیاهی دندان، ویتامین A، D3، C و گروه B",
            description = "تأمین ویتامین‌ها و آهن مورد نیاز رشد نوزادان و کودکان، بهبود اشتها و رشد قدی با طعم مطلوب و بدون طعم فلزی.",
            usageInstruction = "کودکان ۶ ماه تا ۲ سال: روزانه ۱ میلی‌لیتر بعد از وعده غذایی یا طبق تجویز پزشک.",
            warnings = "بیش از مقدار توصیه‌شده مصرف نگردد.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFF00897B,
            badge = "بدون سیاه کردن دندان"
        ),
        Product(
            id = "p-110",
            title = "تب‌سنج دیجیتال مادون قرمز بدون تماس مایکرولایف مدل NC200",
            genericName = "Microlife Non-Contact Digital Forehead Thermometer",
            category = ProductCategory.MEDICAL_EQUIPMENT,
            price = 2850000,
            originalPrice = 3300000,
            discountPercent = 14,
            rating = 4.9f,
            reviewCount = 38,
            inStock = true,
            dosageForm = "تب‌سنج لیزری پیشانی",
            brand = "مایکرولایف (Microlife)",
            country = "سوئیس",
            activeIngredients = "حسگر حرارتی مادون قرمز با فاصله سنج اتوماتیک",
            description = "سنجش دقیق دمای بدن نوزاد، کودک و بزرگسال در ۱ ثانیه بدون ایجاد تماس فیزیکی، دارای هشدار تب رنگی و حافظه ۳۰ سنجش اخیر.",
            usageInstruction = "دستگاه را در فاصله ۵ سانتی‌متری مرکز پیشانی نگه دارید؛ سنسور خودکار دما را ثبت می‌کند.",
            warnings = "پیشانی باید تمیز و بدون عرق یا کرم باشد.",
            isPrescriptionRequired = false,
            isInstallmentEligible = true,
            primaryColorHex = 0xFF0284C7,
            badge = "سنجش ۱ ثانیه‌ای"
        ),
        Product(
            id = "p-111",
            title = "کپسول ژلاتینی امگا ۳ ۱۰۰۰ میلی‌گرم بدون جیوه زهراوی",
            genericName = "Omega 3 Fish Oil 1000mg Mercury Free",
            category = ProductCategory.MEDICINE,
            price = 210000,
            originalPrice = 260000,
            discountPercent = 19,
            rating = 4.8f,
            reviewCount = 59,
            inStock = true,
            dosageForm = "کپسول نرم ژلاتینی (بسته ۵۰ عددی)",
            brand = "داروسازی زهراوی",
            country = "ایران",
            activeIngredients = "روغن ماهی تصفیه شده حاوی ۱۸۰ میلی‌گرم EPA و ۱۲۰ میلی‌گرم DHA",
            description = "کاهش تری‌گلیسیرید خون، پیشگیری از بیماری‌های قلبی عروقی، بهبود تمرکز و کاهش التهابات مفصلی.",
            usageInstruction = "روزانه ۱ الی ۲ عدد همراه با آب کافی بعد از غذا میل شود.",
            warnings = "مصرف‌کنندگان داروهای ضدانعقاد مانند وارفارین قبل از مصرف با پزشک هماهنگ کنند.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFF059669,
            badge = "تصفیه شده بدون جیوه"
        ),
        Product(
            id = "p-112",
            title = "قرص جوشان زینک پلاس ب کمپلکس یوروویتال",
            genericName = "Eurhovital Zinc Plus B-Complex Effervescent",
            category = ProductCategory.SUPPLEMENTS,
            price = 190000,
            originalPrice = 240000,
            discountPercent = 21,
            rating = 4.7f,
            reviewCount = 33,
            inStock = true,
            dosageForm = "قرص جوشان ۲۰ عددی با طعم انبه",
            brand = "یوروویتال (Eurhovital)",
            country = "آلمان (تحت لیسانس)",
            activeIngredients = "زینک ۱۵ میلی‌گرم، ویتامین‌های گروه B، ویتامین C",
            description = "جلوگیری از ریزش مو، تقویت ناخن‌های شکننده، افزایش شادابی و رفع خستگی روزمره.",
            usageInstruction = "روزانه یک عدد در یک لیوان آب خنک حل کرده و پس از حل کامل میل نمایید.",
            warnings = "افراد مبتلا به زخم معده فعال همراه با غذا مصرف کنند.",
            isPrescriptionRequired = false,
            isInstallmentEligible = false,
            primaryColorHex = 0xFF00897B,
            badge = "جذب فوق‌العاده"
        )
    )

    val initialArticles: List<HealthArticle> = listOf(
        HealthArticle(
            id = "art-1",
            title = "بهترین زمان مصرف ویتامین D و راه‌های افزایش جذب آن",
            category = "مکمل‌ها و تغذیه",
            author = "دکتر رضا کریمی (متخصص فارماکولوژی)",
            datePersian = "۲۱ شهریور ۱۴۰۵",
            readingTime = "۴ دقیقه مطالعه",
            summary = "ویتامین D یکی از ویتامین‌های محلول در چربی است که مصرف آن در زمان نادرست می‌تواند جذب آن را تا ۵۰ درصد کاهش دهد.",
            content = "تحقیقات بالینی نشان می‌دهند که ویتامین D به عنوان یک ویتامین محلول در چربی، برای حل شدن و ورود به جریان خون نیاز به مولکول‌های چربی دارد. بنابراین، مصرف قرص یا سافت‌ژل ویتامین D با شکم خالی باعث دفع بخش عمده آن خواهد شد.\n\nبهترین زمان مصرف، همراه با بزرگ‌ترین وعده غذایی روز (معمولاً ناهار یا شامی که حاوی مقداری روغن زیتون، آووکادو، تخم‌مرغ یا لبنیات است) می‌باشد. همچنین بررسی‌های اخیر نشان داده مصرف آن قبل از خواب ممکن است در برخی افراد موجب کاهش ترشح ملاتونین و اختلال در ریتم خواب گردد.",
            hasVideo = true,
            videoTitle = "ویدیو آموزشی: اشتباهات رایج در مصرف مکمل‌های ویتامینی",
            videoDuration = "۰۳:۴۵",
            keyTakeaways = listOf(
                "همیشه ویتامین D را همراه با وعده غذایی حاوی چربی سالم میل کنید.",
                "از مصرف دوزهای بالای ۵۰۰۰۰ واحد بدون آزمایش خون خودداری کنید.",
                "در صورت مصرف قرص کلسیم، مصرف همزمان با ویتامین D جذب کلسیم را دوبرابر می‌کند."
            ),
            relatedProductIds = listOf("p-101", "p-106")
        ),
        HealthArticle(
            id = "art-2",
            title = "راهنمای قدم به قدم اندازه‌گیری صحیح فشار خون در منزل",
            category = "تجهیزات پزشکی",
            author = "دکتر مریم شمس (داروساز بالینی)",
            datePersian = "۱۸ شهریور ۱۴۰۵",
            readingTime = "۶ دقیقه مطالعه",
            summary = "بسیاری از بیماران به دلیل رعایت نکردن چند نکته ساده، نتایج کاذب و غیردقیق از فشارسنج‌های خانگی دریافت می‌کنند.",
            content = "فشارسنج‌های دیجیتال بازویی استانداردهای طلایی پایش فشار خون در منزل هستند. با این حال، خطاهایی مانند پر بودن مثانه، صحبت کردن حین تست، یا بستن شل کاف می‌تواند فشار را تا ۱۵ میلی‌متر جیوه بالاتر یا پایین‌تر نشان دهد.\n\nتوصیه می‌شود نیم ساعت قبل از تست، از مصرف چای، قهوه و سیگار خودداری کنید. ۵ دقیقه با آرامش روی صندلی بنشینید، تکیه دهید و دست خود را روی میز هم‌سطح قلب قرار دهید.",
            hasVideo = true,
            videoTitle = "ویدیو نحوه صحیح بستن کاف و عیب‌یابی خطای Err دستگاه",
            videoDuration = "۰۴:۲۰",
            keyTakeaways = listOf(
                "کاف باید دقیقاً ۲ سانتی‌متر بالای خم داخلی آرنج بسته شود.",
                "فشارسنج‌های بازویی بسیار دقیق‌تر از مدل‌های مچی هستند.",
                "هر بار ۲ سنجش با فاصله ۱ دقیقه انجام داده و میانگین را ثبت کنید."
            ),
            relatedProductIds = listOf("p-102")
        ),
        HealthArticle(
            id = "art-3",
            title = "پروتئین وی چیست و چگونه از اصالت مکمل‌های بدنسازی اطمینان حاصل کنیم؟",
            category = "مکمل‌های ورزشی",
            author = "دکتر ساسان نادری (مشاور تغذیه و مکمل)",
            datePersian = "۱۴ شهریور ۱۴۰۵",
            readingTime = "۵ دقیقه مطالعه",
            summary = "تفاوت پروتئین وی کنسانتره و ایزوله و بررسی بارکد سازمان غذا و دارو (تی‌تک TTAC) جهت تضمین سلامت مصرف‌کننده.",
            content = "پروتئین وی محصول جانبی فرآیند پنیرسازی است که حاوی کامل‌ترین پروفایل اسیدهای آمینه ضروری است. مدل ایزوله به دلیل تصفیه فیلتراسیون بیشتر، دارای کمترین مقدار لاکتوز و کربوهیدرات بوده و برای افرادی که رژیم کات دارند یا به لاکتوز حساس هستند بهترین انتخاب است.\n\nتمامی مکمل‌های ارائه‌شده در داروخانه‌های رسمی ملزم به داشتن برچسب اصالت سازمان غذا و دارو (TTAC) و کد ۱۶ رقمی قابل استعلام پیامکی هستند.",
            hasVideo = true,
            videoTitle = "ویدیو آزمایش حلالیت و بررسی لیبل اصالت کالا",
            videoDuration = "۰۲:۵۰",
            keyTakeaways = listOf(
                "تنها مکمل‌هایی که دارای برچسب زرد و نقره‌ای TTAC هستند اصالت تضمینی دارند.",
                "زمان طلایی مصرف پروتئین وی تا ۴۵ دقیقه پس از تمرین مقاومتی است."
            ),
            relatedProductIds = listOf("p-103", "p-112")
        )
    )

    val sampleReviews: Map<String, List<ProductReview>> = mapOf(
        "p-102" to listOf(
            ProductReview(
                id = "r-1",
                author = "مهندس کامران رستمی",
                rating = 5,
                datePersian = "۲ روز پیش",
                comment = "دستگاه فوق‌العاده دقیق و با کیفیتی است. من با فشارسنج جیوه‌ای مطب دکتر مقایسه کردم دقیقاً همان عدد را نشان داد. صفحه لمسی و خوانا بودن اعداد برای افراد مسن عالیه.",
                isVerifiedBuyer = true,
                pros = listOf("دقت آلمانی بالا", "کاف بزرگ و راحت", "تشخیص آریتمی قلبی"),
                cons = listOf("قیمت نسبتاً بالا اما ارزش دارد")
            ),
            ProductReview(
                id = "r-2",
                author = "سارا مهدوی",
                rating = 5,
                datePersian = "هفته گذشته",
                comment = "از طریق گزینه خرید اقساطی صیادی مرکز دارو خریدم. دو ساعته تایید شد و چک‌ها ثبت شد، بسته‌بندی عالی بود و به موقع تحویل گرفتم.",
                isVerifiedBuyer = true,
                pros = listOf("امکان پرداخت با چک صیادی", "پشتیبانی سریع داروخانه"),
                cons = emptyList()
            )
        ),
        "p-104" to listOf(
            ProductReview(
                id = "r-3",
                author = "دکتر فرنوش صادقی",
                rating = 5,
                datePersian = "۳ روز پیش",
                comment = "سرم ویتامین سی لافارر بافت بسیار سبکی دارد و اصلاً پوست را چرب نمی‌کند. بعد از سه هفته استفاده لک‌های آفتاب سوختگی کاملاً کمرنگ شدند.",
                isVerifiedBuyer = true,
                pros = listOf("جذب سریع", "بوی ملایم مرکبات", "روشن‌کنندگی ملموس"),
                cons = listOf("حتماً باید در یخچال نگهداری شود تا اکسید نشود")
            )
        )
    )

    val initialTickets: List<SupportTicket> = listOf(
        SupportTicket(
            id = "t-101",
            trackingCode = "TCK-8921",
            subject = "استعلام تایید اصالت چک صیادی برای دستگاه بیورر",
            department = TicketDepartment.INSTALLMENT_SAYAD,
            priority = TicketPriority.NORMAL,
            status = TicketStatus.ANSWERED,
            createdDate = "۲ ساعت پیش",
            messages = listOf(
                TicketMessage(
                    id = "tm-1",
                    sender = "کاربر",
                    isSupport = false,
                    message = "سلام، من شناسه ۱۶ رقمی صیادی چک قسط اول را در سامانه پیچک ثبت کردم، آیا تأیید شده است؟",
                    timePersian = "۱۰:۳۰"
                ),
                TicketMessage(
                    id = "tm-2",
                    sender = "واحد مالی و اعتبارسنجی مرکز دارو",
                    isSupport = true,
                    message = "با سلام و احترام، بله شناسه صیادی شما در سامانه بانک مرکزی استعلام گردید و وضعیت آن سفید می‌باشد. کالای شما وارد مرحله بسته‌بندی شد.",
                    timePersian = "۱۱:۱۵"
                )
            )
        ),
        SupportTicket(
            id = "t-102",
            trackingCode = "TCK-8924",
            subject = "تداخل دارویی کپسول امگا ۳ با داروی رقیق‌کننده خون",
            department = TicketDepartment.PHARMACIST_CONSULT,
            priority = TicketPriority.URGENT,
            status = TicketStatus.ANSWERED,
            createdDate = "دیروز",
            messages = listOf(
                TicketMessage(
                    id = "tm-3",
                    sender = "کاربر",
                    isSupport = false,
                    message = "پدرم داروی پلاویکس مصرف می‌کنند، آیا می‌توانند امگا ۳ زهراوی را هم روزانه بخورند؟",
                    timePersian = "۱۶:۴۰"
                ),
                TicketMessage(
                    id = "tm-4",
                    sender = "دکتر داروساز مسئول فنی",
                    isSupport = true,
                    message = "با درود، با توجه به اثر ضدپلاکتی امگا ۳ در دوزهای بالای ۱ گرم و مصرف همزمان پلاویکس، ریسک خونریزی بالا می‌رود. توصیه می‌شود بدون نظر پزشک متخصص قلب مصرف نگردد یا دوز آن به کمتر از ۵۰۰ میلی‌گرم محدود شود.",
                    timePersian = "۱۷:۰۵"
                )
            )
        )
    )

    val initialOrders: List<Order> = listOf(
        Order(
            id = "ord-5501",
            trackingCode = "IR-DAROO-982410",
            items = listOf(
                CartItem(initialProducts[0], 2),
                CartItem(initialProducts[5], 1)
            ),
            totalAmount = 530000,
            discountAmount = 80000,
            payableAmount = 450000,
            datePersian = "۲۲ شهریور ۱۴۰۵",
            status = OrderStatus.DISPATCHED,
            paymentGateway = "درگاه پرداخت الکترونیک سامان (شاپرک)",
            isInstallment = false,
            shippingAddress = "تهران، خیابان ولیعصر، نرسیده به میدان ونک، پلاک ۲۴، واحد ۵",
            recipientName = "علی لطیفی",
            recipientPhone = "09123456789"
        ),
        Order(
            id = "ord-5502",
            trackingCode = "IR-DAROO-982411",
            items = listOf(
                CartItem(initialProducts[1], 1)
            ),
            totalAmount = 4850000,
            discountAmount = 0,
            payableAmount = 4850000,
            datePersian = "۱۹ شهریور ۱۴۰۵",
            status = OrderStatus.DELIVERED,
            paymentGateway = "خرید اقساطی ۳ ماهه با چک صیادی",
            isInstallment = true,
            sayadChequeCount = 3,
            shippingAddress = "اصفهان، خیابان چهارباغ بالا، مجتمع کوثر، طبقه ۳",
            recipientName = "علی لطیفی",
            recipientPhone = "09123456789"
        )
    )

    val initialNotifications: List<AppNotification> = listOf(
        AppNotification(
            id = "n-1",
            title = "🎉 کد تخفیف ویژه بازگشت شما!",
            body = "کد تخفیف اختصاصی DAROO20 با ۲۰٪ تخفیف تا پایان امشب برای سبد خرید شما فعال است.",
            timeAgo = "۱۰ دقیقه پیش",
            type = NotificationType.DISCOUNT,
            couponCode = "DAROO20"
        ),
        AppNotification(
            id = "n-2",
            title = "📦 وضعیت سفارش شما تغییر کرد",
            body = "سفارش شماره IR-DAROO-982410 به مأمور پست پیشتاز تحویل داده شد.",
            timeAgo = "۲ ساعت پیش",
            type = NotificationType.ORDER_STATUS
        ),
        AppNotification(
            id = "n-3",
            title = "💊 یادآور سلامت ماهانه",
            body = "زمان مصرف دوز ماهانه کپسول ویتامین D3 فرارسیده است. سلامتی پایدار با مرکز دارو.",
            timeAgo = "دیروز",
            type = NotificationType.HEALTH_REMINDER
        )
    )
}
