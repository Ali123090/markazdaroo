package com.example.data

import com.example.data.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class PharmacyRepository {

    private val _products = MutableStateFlow<List<Product>>(PharmacyData.initialProducts)
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _comparisonList = MutableStateFlow<List<Product>>(emptyList())
    val comparisonList: StateFlow<List<Product>> = _comparisonList.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(PharmacyData.initialOrders)
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _tickets = MutableStateFlow<List<SupportTicket>>(PharmacyData.initialTickets)
    val tickets: StateFlow<List<SupportTicket>> = _tickets.asStateFlow()

    private val _articles = MutableStateFlow<List<HealthArticle>>(PharmacyData.initialArticles)
    val articles: StateFlow<List<HealthArticle>> = _articles.asStateFlow()

    private val _notifications = MutableStateFlow<List<AppNotification>>(PharmacyData.initialNotifications)
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _liveChatMessages = MutableStateFlow<List<LiveChatMessage>>(listOf(
        LiveChatMessage(
            id = "m-init-1",
            senderName = "دکتر داروساز هوشمند",
            isUser = false,
            isAiPharmacist = true,
            text = "سلام و درود! به مرکز دارو خوش آمدید. من هوش مصنوعی مشاور داروساز شما هستم. می‌توانید هرگونه سوال در مورد انتخاب مکمل، تداخلات دارویی، دوز مصرف یا تجهیزات پزشکی را بپرسید.",
            timePersian = "۱۰:۰۰",
            suggestedProductIds = listOf("p-101", "p-106")
        )
    ))
    val liveChatMessages: StateFlow<List<LiveChatMessage>> = _liveChatMessages.asStateFlow()

    private val _appliedCouponCode = MutableStateFlow<String?>(null)
    val appliedCouponCode: StateFlow<String?> = _appliedCouponCode.asStateFlow()

    private val _appliedDiscountPercent = MutableStateFlow(0)
    val appliedDiscountPercent: StateFlow<Int> = _appliedDiscountPercent.asStateFlow()

    // Exit discount popup state
    private val _showExitDiscountPopup = MutableStateFlow(false)
    val showExitDiscountPopup: StateFlow<Boolean> = _showExitDiscountPopup.asStateFlow()

    // Cart operations
    fun addToCart(product: Product, quantity: Int = 1) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(quantity = item.quantity + quantity)
        } else {
            current.add(CartItem(product, quantity))
        }
        _cartItems.value = current
    }

    fun updateCartQuantity(productId: String, delta: Int) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            val currentItem = current[index]
            val newQty = currentItem.quantity + delta
            if (newQty <= 0) {
                current.removeAt(index)
            } else {
                current[index] = currentItem.copy(quantity = newQty)
            }
            _cartItems.value = current
        }
    }

    fun removeFromCart(productId: String) {
        _cartItems.value = _cartItems.value.filterNot { it.product.id == productId }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _appliedCouponCode.value = null
        _appliedDiscountPercent.value = 0
    }

    // Coupon logic
    fun applyCoupon(code: String): Boolean {
        val clean = code.trim().uppercase()
        return when (clean) {
            "SALAMAT15" -> {
                _appliedCouponCode.value = "SALAMAT15"
                _appliedDiscountPercent.value = 15
                true
            }
            "DAROO20" -> {
                _appliedCouponCode.value = "DAROO20"
                _appliedDiscountPercent.value = 20
                true
            }
            "NOROOZ10" -> {
                _appliedCouponCode.value = "NOROOZ10"
                _appliedDiscountPercent.value = 10
                true
            }
            else -> false
        }
    }

    fun removeCoupon() {
        _appliedCouponCode.value = null
        _appliedDiscountPercent.value = 0
    }

    // Exit intent popup
    fun triggerExitDiscountPopup() {
        if (_cartItems.value.isNotEmpty() && _appliedCouponCode.value == null) {
            _showExitDiscountPopup.value = true
        }
    }

    fun dismissExitDiscountPopup() {
        _showExitDiscountPopup.value = false
    }

    // Product Comparison
    fun toggleProductComparison(product: Product): Boolean {
        val current = _comparisonList.value.toMutableList()
        val exists = current.any { it.id == product.id }
        if (exists) {
            current.removeAll { it.id == product.id }
            _comparisonList.value = current
            return false
        } else {
            if (current.size >= 3) {
                current.removeAt(0) // keep at most 3
            }
            current.add(product)
            _comparisonList.value = current
            return true
        }
    }

    fun clearComparison() {
        _comparisonList.value = emptyList()
    }

    // Sayad Cheque Calculation
    fun calculateSayadInstallments(
        totalAmount: Long,
        downPaymentPercent: Int = 25,
        months: Int = 6
    ): SayadCalculationResult {
        val downPayment = (totalAmount * downPaymentPercent) / 100
        val principal = totalAmount - downPayment
        // Interest rate e.g. 2.5% per month for Sayad credit check
        val interestRate = when (months) {
            3 -> 4.0f
            6 -> 7.5f
            12 -> 14.0f
            24 -> 25.0f
            else -> 6.0f
        }
        val interestAmount = ((principal * interestRate) / 100).toLong()
        val totalWithInterest = principal + interestAmount
        val monthlyPayment = if (months > 0) totalWithInterest / months else 0L

        // Generate dates for each cheque (1 cheque every month or 2 months)
        val cheques = mutableListOf<SayadChequeItem>()
        for (i in 1..months) {
            cheques.add(
                SayadChequeItem(
                    chequeNumber = i,
                    dueDate = "ماه $i پس از خرید",
                    amountTomans = monthlyPayment,
                    sayadId = "1405" + (1000000000L + (i * 12345678L)).toString().take(12)
                )
            )
        }

        return SayadCalculationResult(
            totalAmount = totalAmount,
            downPayment = downPayment,
            remainingAmount = principal,
            months = months,
            interestPercent = interestRate,
            monthlyPayment = monthlyPayment,
            totalWithInterest = totalWithInterest + downPayment,
            cheques = cheques
        )
    }

    // Orders
    fun placeOrder(
        gateway: String,
        isInstallment: Boolean,
        sayadCheques: Int,
        address: String,
        name: String,
        phone: String
    ): Order {
        val items = _cartItems.value
        var rawTotal = items.sumOf { it.product.price * it.quantity }
        val discount = if (_appliedDiscountPercent.value > 0) {
            (rawTotal * _appliedDiscountPercent.value) / 100
        } else 0L
        val payable = (rawTotal - discount).coerceAtLeast(0)

        val newOrder = Order(
            id = "ord-${System.currentTimeMillis().toString().takeLast(4)}",
            trackingCode = "IR-DAROO-${(100000..999999).random()}",
            items = items,
            totalAmount = rawTotal,
            discountAmount = discount,
            payableAmount = payable,
            datePersian = "امروز - ۲۳ شهریور ۱۴۰۵",
            status = OrderStatus.REGISTERED,
            paymentGateway = gateway,
            isInstallment = isInstallment,
            sayadChequeCount = sayadCheques,
            shippingAddress = address,
            recipientName = name,
            recipientPhone = phone
        )

        _orders.value = listOf(newOrder) + _orders.value
        clearCart()
        return newOrder
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        val current = _orders.value.toMutableList()
        val index = current.indexOfFirst { it.id == orderId }
        if (index >= 0) {
            current[index] = current[index].copy(status = newStatus)
            _orders.value = current
        }
    }

    // Support Ticket
    fun createTicket(
        subject: String,
        department: TicketDepartment,
        priority: TicketPriority,
        initialMessage: String
    ): SupportTicket {
        val newTicket = SupportTicket(
            id = "t-${System.currentTimeMillis().toString().takeLast(4)}",
            trackingCode = "TCK-${(1000..9999).random()}",
            subject = subject,
            department = department,
            priority = priority,
            status = TicketStatus.OPEN,
            createdDate = "لحظاتی پیش",
            messages = listOf(
                TicketMessage(
                    id = "msg-${UUID.randomUUID().toString().take(6)}",
                    sender = "کاربر",
                    isSupport = false,
                    message = initialMessage,
                    timePersian = "الان"
                )
            )
        )
        _tickets.value = listOf(newTicket) + _tickets.value
        return newTicket
    }

    fun replyToTicket(ticketId: String, text: String, isSupport: Boolean = false) {
        val current = _tickets.value.toMutableList()
        val index = current.indexOfFirst { it.id == ticketId }
        if (index >= 0) {
            val ticket = current[index]
            val updatedMessages = ticket.messages + TicketMessage(
                id = "msg-${UUID.randomUUID().toString().take(6)}",
                sender = if (isSupport) "پشتیبان داروخانه" else "کاربر",
                isSupport = isSupport,
                message = text,
                timePersian = "الان"
            )
            current[index] = ticket.copy(
                messages = updatedMessages,
                status = if (isSupport) TicketStatus.ANSWERED else TicketStatus.OPEN
            )
            _tickets.value = current
        }
    }

    // Live Chat & AI Pharmacist Assistant
    fun sendUserChatMessage(text: String) {
        val userMsg = LiveChatMessage(
            id = "msg-u-${System.currentTimeMillis()}",
            senderName = "شما",
            isUser = true,
            isAiPharmacist = false,
            text = text,
            timePersian = "الان"
        )
        _liveChatMessages.value = _liveChatMessages.value + userMsg

        // AI Pharmacist Smart Response
        val response = generateSmartPharmacistReply(text)
        _liveChatMessages.value = _liveChatMessages.value + response
    }

    private fun generateSmartPharmacistReply(query: String): LiveChatMessage {
        val q = query.lowercase()
        return when {
            q.contains("خستگی") || q.contains("انرژی") || q.contains("بی‌حال") -> {
                LiveChatMessage(
                    id = "msg-ai-${System.currentTimeMillis()}",
                    senderName = "دکتر داروساز (هوش مصنوعی)",
                    isUser = false,
                    isAiPharmacist = true,
                    text = "برای رفع خستگی مفرط و افت انرژی روزانه، بررسی سطح ویتامین D3 و فریتین خون اولویت دارد. سافت‌ژل ویتامین D3 ۵۰۰۰۰ و قرص جوشان زینک پلاس ب کمپلکس توصیه می‌شود.",
                    timePersian = "الان",
                    suggestedProductIds = listOf("p-101", "p-112")
                )
            }
            q.contains("فشار") || q.contains("قلب") || q.contains("فشارسنج") -> {
                LiveChatMessage(
                    id = "msg-ai-${System.currentTimeMillis()}",
                    senderName = "دکتر داروساز (هوش مصنوعی)",
                    isUser = false,
                    isAiPharmacist = true,
                    text = "پایش منظم فشار خون برای سلامت قلب حیاتی است. فشارسنج دیجیتال بازویی بیورر آلمان با تشخیص آریتمی و کاف استاندارد در مرکز دارو موجود است و امکان خرید اقساطی با چک صیادی نیز دارد.",
                    timePersian = "الان",
                    suggestedProductIds = listOf("p-102", "p-111")
                )
            }
            q.contains("پوست") || q.contains("لک") || q.contains("جوش") || q.contains("ترمیم") -> {
                LiveChatMessage(
                    id = "msg-ai-${System.currentTimeMillis()}",
                    senderName = "دکتر داروساز (هوش مصنوعی)",
                    isUser = false,
                    isAiPharmacist = true,
                    text = "جهت رفع لک و جوانسازی، سرم ویتامین C با فرمولاسیون پایدار لافارر و برای جای زخم و التهاب، کرم ترمیم‌کننده اون سیکالفیت بهترین انتخاب‌های درماتولوژی هستند.",
                    timePersian = "الان",
                    suggestedProductIds = listOf("p-104", "p-108", "p-107")
                )
            }
            q.contains("ورزش") || q.contains("عضله") || q.contains("بدنسازی") || q.contains("پروتئین") -> {
                LiveChatMessage(
                    id = "msg-ai-${System.currentTimeMillis()}",
                    senderName = "دکتر داروساز (هوش مصنوعی)",
                    isUser = false,
                    isAiPharmacist = true,
                    text = "برای عضله‌سازی بدون چربی و تسریع ریکاوری بعد از تمرین، پودر پروتئین وی ایزوله ۱۰۰٪ دارای بیشترین ارزش بیولوژیکی و خلوص بالاست.",
                    timePersian = "الان",
                    suggestedProductIds = listOf("p-103", "p-112")
                )
            }
            q.contains("سرماخوردگی") || q.contains("ایمنی") || q.contains("گلو درد") || q.contains("کودک") -> {
                LiveChatMessage(
                    id = "msg-ai-${System.currentTimeMillis()}",
                    senderName = "دکتر داروساز (هوش مصنوعی)",
                    isUser = false,
                    isAiPharmacist = true,
                    text = "برای تقویت سیستم ایمنی و کوتاه کردن دوره بیماری، شربت ایمیونس ویتابیوتیکس حاوی اکیناسه و زینک عالی است. برای کودکان نیز قطره پدیابست توصیه می‌شود.",
                    timePersian = "الان",
                    suggestedProductIds = listOf("p-106", "p-109")
                )
            }
            else -> {
                LiveChatMessage(
                    id = "msg-ai-${System.currentTimeMillis()}",
                    senderName = "دکتر داروساز (هوش مصنوعی)",
                    isUser = false,
                    isAiPharmacist = true,
                    text = "پرسش شما ثبت شد. کلیه اقلام ارائه‌شده در مرکز دارو دارای برچسب اصالت TTAC سازمان غذا و دارو بوده و با ضمانت اصالت و امکان بازگشت ۷ روزه ارسال می‌شوند. در صورت نیاز به بررسی دوز خاص بفرمایید تا راهنمایی دقیق‌تری ارائه شود.",
                    timePersian = "الان",
                    suggestedProductIds = listOf("p-101", "p-105")
                )
            }
        }
    }

    // Admin Operations
    fun addProduct(product: Product) {
        _products.value = listOf(product) + _products.value
    }

    fun deleteProduct(productId: String) {
        _products.value = _products.value.filterNot { it.id == productId }
    }

    fun addArticle(article: HealthArticle) {
        _articles.value = listOf(article) + _articles.value
    }
}
